// ── Backend URL detection ──────────────────────────────────────────
const _RENDER_HOST = "wrennon-1.onrender.com";
const IS_LOCAL = window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1';
const BACKEND_URL = IS_LOCAL ? `${window.location.protocol}//${window.location.host}` : `https://${_RENDER_HOST}`;

const API_BASE = `${BACKEND_URL}/api`;
const WS_URL = IS_LOCAL 
  ? `${window.location.protocol === 'https:' ? 'wss' : 'ws'}://${window.location.host}/ws/agent`
  : `wss://${_RENDER_HOST}/ws/agent`;

window.showToast = function(msg, type = 'info') {
    const toast = document.createElement('div');
    toast.style.position = 'fixed';
    toast.style.bottom = '24px';
    toast.style.right = '24px';
    toast.style.padding = '12px 24px';
    toast.style.background = type === 'error' ? 'var(--accent-alert, #ef4444)' : 'var(--accent, #6366f1)';
    toast.style.color = '#ffffff';
    toast.style.borderRadius = '8px';
    toast.style.boxShadow = 'var(--shadow-lg)';
    toast.style.zIndex = '99999';
    toast.style.fontFamily = "'Inter', sans-serif";
    toast.style.fontWeight = '500';
    toast.style.animation = 'fadeInBounce 0.3s ease-out';
    toast.innerText = msg;
    document.body.appendChild(toast);
    
    toast.style.cursor = 'pointer';
    toast.onclick = () => toast.remove();
    
    setTimeout(() => {
        if(toast.parentElement) {
            toast.style.animation = 'fadeOut 0.3s ease-in forwards';
            setTimeout(() => toast.remove(), 300);
        }
    }, 8000);
};

if (!document.getElementById('toast-styles')) {
    const style = document.createElement('style');
    style.id = 'toast-styles';
    style.textContent = `
        @keyframes fadeInBounce {
            0% { transform: translateY(20px) scale(0.9); opacity: 0; }
            60% { transform: translateY(-5px) scale(1.02); opacity: 1; }
            100% { transform: translateY(0) scale(1); opacity: 1; }
        }
        @keyframes fadeOut {
            to { opacity: 0; transform: translateY(10px); }
        }
    `;
    document.head.appendChild(style);
}

let socket = null;
let activeSessionId = null;
let _agentToken = null; // stored on login for WebSocket auth
let activeSection = "active"; // "attention" | "active" | "all"
const drafts = {};

// --- Elements ---
const loginScreen = document.getElementById("login-screen");
const dashboard = document.getElementById("dashboard");
const loginForm = document.getElementById("login-form");
const loginError = document.getElementById("login-error");
const logoutBtn = document.getElementById("logout-btn");
const connectionDot = document.getElementById("connection-dot");
const sectionTabs = document.querySelectorAll(".tab");
const conversationList = document.getElementById("conversation-list");
const attentionCount = document.getElementById("attention-count");
const activeCount = document.getElementById("active-count");
const emptyState = document.getElementById("empty-state");
const activeConversationEl = document.getElementById("active-conversation");
const conversationEmail = document.getElementById("conversation-email");
const conversationSession = document.getElementById("conversation-session");
const agentMessages = document.getElementById("agent-messages");
const agentInput = document.getElementById("agent-message-input");

// ── Theme Management ───────────────────────────────────────────────
function setupThemeDropdown() {
  const menuBtn = document.getElementById("theme-menu-btn");
  const dropdown = document.getElementById("theme-dropdown");
  const options = document.querySelectorAll(".theme-option");
  if (!menuBtn || !dropdown) return;

  const menuMainView = document.getElementById("menu-main-view");
  const menuAppearanceView = document.getElementById("menu-appearance-view");
  const btnShowAppearance = document.getElementById("btn-show-appearance");
  const btnBackAppearance = document.getElementById("btn-back-appearance");

  function applyTheme(themeValue) {
    if (themeValue.startsWith("widget-")) {
      localStorage.setItem("wrennon_widget_theme", themeValue);
    } else {
      localStorage.setItem("wrennon_theme", themeValue);
      if (themeValue === "system") {
        const isDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute("data-theme", isDark ? "dark-matte" : "light-offwhite");
      } else {
        document.documentElement.setAttribute("data-theme", themeValue);
      }
      
      // Update charts to reflect new theme accent colors
      if (window.refreshCharts) {
        setTimeout(window.refreshCharts, 50);
      }
    }
    
    options.forEach(opt => {
      if (opt.dataset.themeValue) {
        const isWidgetOpt = opt.dataset.themeValue.startsWith("widget-");
        const isWidgetTheme = themeValue.startsWith("widget-");
        if (isWidgetOpt === isWidgetTheme) {
          opt.classList.toggle("active", opt.dataset.themeValue === themeValue);
        }
      }
    });
  }

  menuBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const isExpanded = menuBtn.getAttribute("aria-expanded") === "true";
    menuBtn.setAttribute("aria-expanded", !isExpanded);
    dropdown.classList.toggle("hidden");

    if (!dropdown.classList.contains("hidden") && menuMainView && menuAppearanceView) {
      menuMainView.classList.remove("hidden");
      menuAppearanceView.classList.add("hidden");
    }

    if (!isExpanded && options.length > 0) {
      options[0].focus();
    }
  });

  if (btnShowAppearance && menuMainView && menuAppearanceView) {
    btnShowAppearance.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      menuMainView.classList.add("hidden");
      menuAppearanceView.classList.remove("hidden");
    });
  }

  if (btnBackAppearance && menuMainView && menuAppearanceView) {
    btnBackAppearance.addEventListener("click", (e) => {
      e.preventDefault();
      e.stopPropagation();
      menuAppearanceView.classList.add("hidden");
      menuMainView.classList.remove("hidden");
    });
  }

  document.addEventListener("click", (e) => {
    if (!e.target.closest("#theme-dropdown") && !e.target.closest("#theme-menu-btn")) {
      dropdown.classList.add("hidden");
      menuBtn.setAttribute("aria-expanded", "false");
    }
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      dropdown.classList.add("hidden");
      menuBtn.setAttribute("aria-expanded", "false");
      menuBtn.focus();
    }
  });

  options.forEach(opt => {
    opt.addEventListener("click", () => {
      if (!opt.dataset.themeValue) return; // Don't trigger theme change for submenu navigation buttons
      applyTheme(opt.dataset.themeValue);
      dropdown.classList.add("hidden");
      menuBtn.setAttribute("aria-expanded", "false");
    });
  });

  const currentTheme = localStorage.getItem("wrennon_theme") || "system";
  const currentWidgetTheme = localStorage.getItem("wrennon_widget_theme") || "widget-default";
  applyTheme(currentTheme);
  applyTheme(currentWidgetTheme);

  window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
    if (localStorage.getItem("wrennon_theme") === "system") {
      document.documentElement.setAttribute("data-theme", e.matches ? "dark-matte" : "light-offwhite");
    }
  });
}

function setupProfileDropdown() {
  const profileBtn = document.getElementById("agent-profile-btn");
  const dropdown = document.getElementById("profile-dropdown");
  const logoutBtn = document.getElementById("profile-logout-btn");
  
  if (!profileBtn || !dropdown) return;
  
  profileBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    const isExpanded = profileBtn.getAttribute("aria-expanded") === "true";
    profileBtn.setAttribute("aria-expanded", !isExpanded);
    
    // Update name, role, and DP dynamically
    const nameEl = document.getElementById("profile-dropdown-name");
    const roleEl = document.getElementById("profile-dropdown-role");
    const dpMenuEl = document.getElementById("profile-dropdown-dp");
    if (nameEl) {
      const fullName = localStorage.getItem("agent_full_name");
      const username = localStorage.getItem("agent_username");
      if (fullName && fullName !== "null") nameEl.textContent = fullName;
      else if (username) nameEl.textContent = username;
    }
    if (roleEl) {
      const role = localStorage.getItem("agent_role");
      if (role) roleEl.textContent = role;
    }
    if (dpMenuEl) {
      const dp = localStorage.getItem("agent_dp_url");
      if (dp) dpMenuEl.src = dp;
      else dpMenuEl.src = "/agent/images/default-avatar.png?v=2";
    }
    
    dropdown.classList.toggle("hidden");
  });
  
  document.addEventListener("click", (e) => {
    if (!e.target.closest("#profile-dropdown") && !e.target.closest("#agent-profile-btn")) {
      dropdown.classList.add("hidden");
      profileBtn.setAttribute("aria-expanded", "false");
    }
  });
  
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      dropdown.classList.add("hidden");
      profileBtn.setAttribute("aria-expanded", "false");
    }
  });
  
  if (logoutBtn) {
    logoutBtn.addEventListener("click", () => {
      dropdown.classList.add("hidden");
      if (typeof logout === "function") logout();
    });
  }
  
  const statusOptions = dropdown.querySelectorAll(".status-option");
  const connectionDot = document.getElementById("connection-dot");
  
  statusOptions.forEach(opt => {
    opt.addEventListener("click", () => {
      const status = opt.dataset.status;
      
      // Update checkmarks
      statusOptions.forEach(otherOpt => {
        otherOpt.classList.remove("active");
        const svg = otherOpt.querySelector(".status-check");
        if (svg) svg.style.display = "none";
      });
      opt.classList.add("active");
      const checkSvg = opt.querySelector(".status-check");
      if (checkSvg) checkSvg.style.display = "block";
      
      // Update dot
      if (connectionDot) {
        connectionDot.className = "dot";
        connectionDot.style.backgroundColor = "";
        if (status === "online") connectionDot.classList.add("dot--online");
        else if (status === "offline") connectionDot.classList.add("dot--offline");
        else if (status === "away") connectionDot.style.backgroundColor = "var(--warning)";
      }
      
      dropdown.classList.add("hidden");
      profileBtn.setAttribute("aria-expanded", "false");
    });
  });
}

setupThemeDropdown();
setupProfileDropdown();

if (logoutBtn) {
  logoutBtn.addEventListener("click", logout);
}

let typingTimeout;
let isTyping = false;
agentInput.addEventListener("input", (e) => {
  agentInput.style.height = '44px';
  const newHeight = Math.min(agentInput.scrollHeight, 120);
  agentInput.style.height = newHeight + 'px';
  agentInput.style.overflowY = agentInput.scrollHeight > 120 ? 'auto' : 'hidden';

  if (!activeSessionId || !socket || socket.readyState !== WebSocket.OPEN) return;
  const isInternal = noteTypeSelect && noteTypeSelect.value === "internal";
  if (isInternal) return; // Don't broadcast typing for internal notes
  
  if (!isTyping) {
    socket.send(JSON.stringify({ type: "typing", session_id: activeSessionId }));
    isTyping = true;
  }
  
  clearTimeout(typingTimeout);
  typingTimeout = setTimeout(() => {
    socket.send(JSON.stringify({ type: "stopped_typing", session_id: activeSessionId }));
    isTyping = false;
  }, 1500);
});

const agentSendBtn = document.getElementById("agent-send-btn");
const resolveBtn = document.getElementById("resolve-btn");

// --- Password Toggle ---
const togglePwdBtn = document.getElementById("toggle-pwd");
if (togglePwdBtn) {
  const pwdInput = document.getElementById("password");
  const eyePaths = togglePwdBtn.querySelectorAll(".eye");
  const slashLine = togglePwdBtn.querySelector(".eye-slash");
  
  togglePwdBtn.addEventListener("click", () => {
    if (pwdInput.type === "password") {
      pwdInput.type = "text";
      eyePaths.forEach(p => p.classList.add("hidden"));
      slashLine.classList.remove("hidden");
    } else {
      pwdInput.type = "password";
      eyePaths.forEach(p => p.classList.remove("hidden"));
      slashLine.classList.add("hidden");
    }
  });
}

// --- Login ---
loginForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  loginError.classList.add("hidden");

  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  const body = new URLSearchParams({ username, password });

  try {
    const response = await fetch(`${API_BASE}/agent/login`, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body,
      credentials: "include",
    });

    if (!response.ok) {
      loginError.classList.remove("hidden");
      return;
    }

    const data = await response.json();
    // Store the JWT for WebSocket auth (WS handshakes don't send httpOnly
    // cookies reliably in cross-origin or some same-site scenarios).
    _agentToken = data.access_token;
    localStorage.setItem("agent_username", username); // Save username to identify self
    localStorage.setItem("agent_role", data.role); // Save role to show admin btn
    if (data.full_name) {
      localStorage.setItem("agent_full_name", data.full_name);
    } else {
      localStorage.removeItem("agent_full_name");
    }
    if (data.dp_url) {
      localStorage.setItem("agent_dp_url", data.dp_url);
      document.getElementById("agent-profile-dp").src = data.dp_url;
    } else {
      localStorage.removeItem("agent_dp_url");
      document.getElementById("agent-profile-dp").src = "/agent/images/default-avatar.png?v=2";
    }
    
    if (data.role === "manager" || data.role === "admin") {
      document.getElementById("admin-dashboard-btn").classList.remove("hidden");
      document.getElementById("admin-dashboard-btn").addEventListener("click", () => {
        window.location.href = "/agent/admin_dashboard.html?v=" + new Date().getTime();
      });
    }

    loginScreen.classList.add("hidden");
    dashboard.classList.remove("hidden");

    connectSocket();
    await loadConversations();
    loadAgents();
    loadMacros(); // was previously only called once, pre-login, at script load —
                   // that call always 403s (not authenticated yet) and was never
                   // retried, so @mentions and the assignee dropdown silently had
                   // an empty agent list. Refresh it now that we have a session.
  } catch (err) {
    loginError.classList.remove("hidden");
    console.error(err);
  }
});

// --- WebSocket ---
let reconnectAttempts = 0;
let reconnectTimeout = null;

function connectSocket() {
  if (reconnectTimeout) clearTimeout(reconnectTimeout);

  // No token query param: the backend already accepts the httpOnly
  // access_token cookie for /ws/agent (see Cookie(None) in
  // websocket_routes.py), and the browser attaches it to the WS
  // handshake automatically. Putting the raw JWT in the URL used to mean
  // it would show up in server access logs, browser history, and any
  // Referer header — a plain credential leak with no upside now that the
  // cookie path works. If the cookie is missing/expired/invalid, the
  // server closes with 4401 and onclose() below sends the agent back to
  // login — no client-side pre-check needed.
  const wsUrl = _agentToken ? `${WS_URL}?token=${encodeURIComponent(_agentToken)}` : WS_URL;
  socket = new WebSocket(wsUrl);

  socket.onopen = () => {
    const wasReconnecting = reconnectAttempts > 0;
    reconnectAttempts = 0;
    connectionDot.classList.remove("dot--offline");
    connectionDot.classList.add("dot--online");
    connectionDot.title = "Connected";

    // A WebSocket reconnect has no way to redeliver whatever happened
    // while we were disconnected (network blip, server restart, Render
    // free-tier idling, etc.) — without this, a message sent during that
    // gap would just be silently missing until the agent happened to
    // reopen the conversation (which is effectively what refreshing the
    // page did as a workaround). Resync here instead of waiting for that.
    if (wasReconnecting) {
      if (activeSessionId) {
        fetchAndRenderMessages(activeSessionId);
      }
      loadConversations();
      loadMacros();
    }
  };

  socket.onclose = (event) => {
    connectionDot.classList.remove("dot--online");
    connectionDot.classList.add("dot--offline");

    // The backend closes with code 4401 specifically for auth failures
    // (missing/expired/invalid/revoked token — see websocket_routes.py).
    // Retrying an auth failure with the same dead token forever (this used
    // to keep exponential-backoff-retrying indefinitely, hammering the
    // server every 30s with a token that will never become valid again)
    // helps no one — the fix is to stop and send the agent back to login.
    if (event.code === 4401) {
      connectionDot.title = "Session expired. Please log in again.";
      logout();
      return;
    }

    // Any other disconnect (network blip, server restart, etc.) — keep the
    // existing exponential backoff retry behavior.
    reconnectAttempts++;
    const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000); // max 30s
    connectionDot.title = `Disconnected. Reconnecting in ${delay/1000}s...`;

    reconnectTimeout = setTimeout(connectSocket, delay);
  };

  socket.onmessage = (event) => {
    let data;
    try { data = JSON.parse(event.data); } catch (err) { return; }

    if (data.type === "handoff" || data.type === "reopen") {
      loadConversations();
      if (data.session_id === activeSessionId) {
        if (data.summary) {
          appendMessage("system", `📋 ${data.summary}`);
        }
        if (data.is_resolved) {
          resolveBtn.textContent = "Resolved";
          resolveBtn.disabled = true;
          resolveBtn.classList.remove("btn-primary");
        } else {
          resolveBtn.textContent = "Mark resolved";
          resolveBtn.disabled = false;
          resolveBtn.classList.add("btn-primary");
        }
      }
    } else if (data.type === "new_message") {
      if (data.session_id === activeSessionId) {
        hideCustomerTypingIndicator();
        appendMessage(data.sender, data.content, new Date().toISOString(), data.sender === "agent_internal", data.message_id, data.author_username, data.author_role);
        // Refresh order context whenever a new message arrives (human or bot/ai may trigger order fetching)
        fetchOrderContext(data.session_id);
        if (data.is_resolved) {
          resolveBtn.textContent = "Resolved";
          resolveBtn.disabled = true;
          resolveBtn.classList.remove("btn-primary");
        } else {
          resolveBtn.textContent = "Mark resolved";
          resolveBtn.disabled = false;
          resolveBtn.classList.add("btn-primary");
        }
      }
      loadConversations();
    } else if (data.type === "typing" || data.type === "stopped_typing") {
      // Customer -> agent typing indicator (mirrors the agent -> customer
      // one in widget.js). Only relevant if we're currently looking at
      // that customer's conversation.
      if (data.session_id === activeSessionId) {
        if (data.type === "typing") {
          showCustomerTypingIndicator();
        } else {
          hideCustomerTypingIndicator();
        }
      }
    } else if (data.type === "viewers_update") {
      if (data.session_id === activeSessionId) {
        renderCollisionBadge(data.viewers || []);
      }
    } else if (data.type === "low_csat_alert") {
      if (window.showToast) {
        window.showToast(`🚨 Low CSAT Alert! Session ${data.session_id.substring(0,8)} received a ${data.rating}-star rating: "${data.comment || 'No comment'}"`, 'error');
      }
    } else if (data.type === "presence") {
      const teamList = document.getElementById("team-status-list");
      if (teamList && data.online_agents) {
        teamList.innerHTML = '';
        data.online_agents.forEach(agent => {
          const div = document.createElement('div');
          div.className = 'activity-item';
          div.innerHTML = `
            <div style="width: 32px; height: 32px; border-radius: 50%; background: var(--surface-2); display: flex; align-items: center; justify-content: center; font-weight: 600; color: var(--ink);">
              ${agent.substring(0,2).toUpperCase()}
            </div>
            <div class="activity-details" style="flex: 1; display: flex; justify-content: space-between; align-items: center;">
              <div>
                <strong>${escapeHtml(agent)}</strong>
                <div style="font-size: 12px; color: var(--text-muted); display: flex; align-items: center; gap: 4px;">
                  <span style="display: inline-block; width: 8px; height: 8px; background: var(--success); border-radius: 50%;"></span>
                  Online
                </div>
              </div>
            </div>
          `;
          teamList.appendChild(div);
        });
        if (data.online_agents.length === 0) {
          teamList.innerHTML = '<div style="padding: 16px; color: var(--text-muted); text-align: center;">No agents currently online.</div>';
        }
      }
    } else {
      console.warn("Unrecognized WebSocket message:", data);
    }
  };
}

// --- Collision detection: "another agent has this ticket open too" ---
function renderCollisionBadge(viewers) {
  const badge = document.getElementById("collision-badge");
  if (!badge) return;
  const myUsername = localStorage.getItem("agent_username");
  const others = viewers.filter(v => v !== myUsername);
  if (others.length === 0) {
    badge.classList.add("hidden");
    badge.textContent = "";
    return;
  }
  badge.classList.remove("hidden");
  badge.textContent = others.length === 1
    ? `⚠ ${others[0]} is also viewing this ticket`
    : `⚠ ${others.length} other agents are also viewing this ticket`;
}

// --- Section Tabs ---
sectionTabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    sectionTabs.forEach((t) => t.classList.remove("tab--active"));
    tab.classList.add("tab--active");
    activeSection = tab.dataset.section;
    loadConversations();
  });
});

// --- Loading conversation lists ---
function formatPreview(conv) {
  let msg = conv.last_message;
  if (!msg) return "No messages yet";
  
  // Handle internal notes specially
  if (conv.last_message_is_internal || msg.startsWith("*Internal Note:*")) {
    let noteText = msg.replace(/^\*Internal Note:\*\s*/, '');
    let cleanText = noteText.replace(/\n\n\(Transcript:.*?\)/g, '').replace(/\*\*(.+?)\*\*/g, "$1").replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '$1');
    return `<span style="color: var(--warning); font-weight: 600; font-size: 11px; text-transform: uppercase; margin-right: 4px;">Note:</span>${escapeHtml(cleanText)}`;
  }
  
  // Remove transcript
  let text = msg.replace(/\n\n\(Transcript:.*?\)/g, '');
  
  // Check for Audio/Video
  if (/\[(?:Audio|Video)\]\((https?:\/\/[^\)]+)\)/.test(text)) {
    return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: text-bottom; margin-right: 4px;"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>Voice message`;
  }
  
  // Check for Image
  if (/!\[.*?\]\((https?:\/\/[^\)]+)\)/.test(text)) {
    return `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="vertical-align: text-bottom; margin-right: 4px;"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect><circle cx="8.5" cy="8.5" r="1.5"></circle><polyline points="21 15 16 10 5 21"></polyline></svg>Photo`;
  }
  
  // Strip bold
  text = text.replace(/\*\*(.+?)\*\*/g, "$1");
  // Strip links
  text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, '$1');
  
  return escapeHtml(text);
}

async function loadConversations() {
    if (window.currentView && window.currentView !== 'conversations') return;
    const endpoints = {
    "my_cases": "/agent/conversations/my-cases",
    "attention": "/agent/conversations/needs-attention",
    "active": "/agent/conversations/active",
    "all": "/agent/conversations"
  };
  
  let endpoint = endpoints[activeSection] || endpoints["my_cases"];
  
  const pri = document.getElementById("filter-priority")?.value;
  const ass = document.getElementById("filter-assignee")?.value;
  const tag = document.getElementById("filter-tag")?.value;
  
  const qs = new URLSearchParams();
  if (pri) qs.append("priority", pri);
  if (ass) qs.append("assigned_agent", ass);
  if (tag) qs.append("tag", tag);
  const qStr = qs.toString();
  if (qStr) endpoint += "?" + qStr;

  const fetchUrl = (base) => base + (qStr ? "?" + qStr : "");
  
  // Use Promise.all to fetch concurrently and save time
  const [conversations, myCasesList, attnList, actList] = await Promise.all([
    authedFetch(endpoint),
    activeSection === "my_cases" ? null : authedFetch(fetchUrl(endpoints["my_cases"])),
    activeSection === "attention" ? null : authedFetch(fetchUrl(endpoints["attention"])),
    activeSection === "active" ? null : authedFetch(fetchUrl(endpoints["active"]))
  ]);

  if (!conversations) {
    return;
  }

  // Update badges
  const myCasesCountEl = document.getElementById("my-cases-count");
  if (myCasesCountEl) {
      myCasesCountEl.textContent = activeSection === "my_cases" ? conversations.length : (myCasesList ? myCasesList.length : 0);
  }
  attentionCount.textContent = activeSection === "attention" ? conversations.length : (attnList ? attnList.length : 0);
  activeCount.textContent = activeSection === "active" ? conversations.length : (actList ? actList.length : 0);

  renderConversationList(conversations);
}

function renderConversationList(conversations) {
  conversationList.innerHTML = "";
  selectedConversations.clear();
  updateBulkActionBar();

  for (const conv of conversations) {
    const item = document.createElement("div");
    item.className = "conv-item";
    item.setAttribute("role", "group");
    item.tabIndex = 0;
    item.setAttribute("aria-label", `Conversation with ${conv.customer_name || conv.customer_email || "unknown customer"}`);
    if (conv.handoff_active && !conv.resolved) item.classList.add("conv-item--urgent");
    if (conv.session_id === activeSessionId) {
      item.classList.add("conv-item--selected");
      item.setAttribute("aria-current", "true");
    }

    let badgeClass = "badge--ai";
    let stageText = "AI";

    if (conv.resolved) {
      badgeClass = "badge--resolved";
      stageText = conv.handled_by ? conv.handled_by : "AI";
    } else if (conv.handoff_active) {
      if (conv.handled_by) {
        badgeClass = "badge--agent";
        stageText = conv.handled_by;
      } else {
        badgeClass = "badge--human";
        stageText = "Needs Attention";
      }
    }

    const mentionedBadge = conv.is_mentioned 
      ? `<span class="badge badge--human">Mentioned</span>`
      : "";

    const reopenBadge = conv.reopen_count > 0
      ? `<span class="conv-item__reopen-badge">↩ Reopened${conv.reopen_count > 1 ? ` ×${conv.reopen_count}` : ""}</span>`
      : "";

    let sentimentBadge = '';
    if (conv.sentiment) {
      const s = conv.sentiment.trim().toLowerCase();
      let color = 'var(--ink-soft)';
      if (s.includes('angry') || s.includes('upset') || s.includes('mad')) color = 'var(--accent-alert)';
      else if (s.includes('frustrated') || s.includes('annoyed') || s.includes('sad')) color = 'var(--warning)';
      else if (s.includes('happy') || s.includes('delighted') || s.includes('satisfied') || s.includes('glad')) color = 'var(--accent-success)';
      else if (s.includes('neutral') || s.includes('mixed')) color = 'var(--ink-soft)';
      sentimentBadge = `<span class="badge" style="border-color:${color}; color:${color}">${escapeHtml(conv.sentiment)}</span>`;
    }
    
    // Feature 6: SLA Warning
    let slaBadge = "";
    if (conv.sla_status === "breached") {
      slaBadge = `<span class="badge" style="background: var(--danger); color:white;">Breached SLA</span>`;
    } else if (conv.sla_status === "warning") {
      slaBadge = `<span class="badge" style="background: var(--warning); color:white;">SLA Warning</span>`;
    }
    
    let languageBadge = '';
    if (conv.language && conv.language.toUpperCase() !== 'ENGLISH') {
      languageBadge = `<span class="badge badge--agent">${escapeHtml(conv.language)}</span>`;
    }

    const webSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`;
    const waSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>`;
    const igSvg = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>`;
    
    const platforms = [webSvg, waSvg, igSvg];
    const hash = conv.short_id ? conv.short_id.split('').reduce((a, b) => {a = ((a << 5) - a) + b.charCodeAt(0); return a & a}, 0) : 0;
    const platformIcon = platforms[Math.abs(hash) % platforms.length];

    const customerDisplayName = conv.customer_name || conv.customer_email || "Unknown Customer";
    let avatarHtml = "";
    if (!conv.customer_name && !conv.customer_email) {
      avatarHtml = `<img src="/agent/images/default-avatar.png?v=2" style="width: 28px; height: 28px; border-radius: 50%; object-fit: cover; flex-shrink: 0; border: 1px solid var(--border-light); box-shadow: 0 1px 3px rgba(0,0,0,0.1);" alt="Avatar">`;
    } else {
      const dpId = conv.customer_email || conv.customer_id || conv.session_id || hash;
      avatarHtml = `<img src="https://i.pravatar.cc/150?u=${encodeURIComponent(dpId)}" style="width: 28px; height: 28px; border-radius: 50%; object-fit: cover; flex-shrink: 0; border: 1px solid var(--border-light); box-shadow: 0 1px 3px rgba(0,0,0,0.1);" alt="Avatar" onerror="this.src='/agent/images/default-avatar.png?v=2'">`;
    }

    const shortIdForBadge = conv.short_id || conv.session_id;
    const ticketIdText = shortIdForBadge ? `#${shortIdForBadge.substring(0, 8).toUpperCase()}` : '';

    item.innerHTML = `
      <div class="conv-item-header" style="display: flex; justify-content: space-between;">
        <div style="display: flex; gap: 10px; align-items: center; overflow: hidden;">
            <input type="checkbox" class="conv-checkbox" data-session-id="${conv.session_id}" onclick="event.stopPropagation(); toggleBulkSelection(this, '${conv.session_id}')" style="cursor: pointer; flex-shrink: 0;">
            <span class="conv-item-email" style="display:flex; align-items:center; gap:8px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; font-size: 14px; font-weight: 500;">
                ${avatarHtml}
                <span style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(customerDisplayName)}</span>
                <span style="background: var(--bg-hover); color: var(--text-muted); padding: 1px 6px; border-radius: 4px; font-size: 10px; font-family: monospace; border: 1px solid var(--border-light); line-height: 1.2;">${ticketIdText}</span>
            </span>
        </div>
        <span class="conv-item-time" style="flex-shrink: 0;">${formatSidebarTime(conv.updated_at)}</span>
      </div>
      <div class="conv-item-preview">${formatPreview(conv)}</div>
      <div class="badge-row">
        <span class="badge ${badgeClass}">${stageText}</span>
        ${mentionedBadge}
        ${slaBadge}
        ${sentimentBadge}
        ${languageBadge}
        ${reopenBadge}
        <span class="badge badge--platform" title="Source">${platformIcon}</span>
      </div>
    `;

    item.addEventListener("click", () => openConversation(conv.session_id, conv.customer_email, conv.short_id, conv.resolved, conv.updated_at));
    item.addEventListener("keydown", (e) => {
      if ((e.key === "Enter" || e.key === " ") && e.target === item) {
        e.preventDefault();
        openConversation(conv.session_id, conv.customer_email, conv.short_id, conv.resolved, conv.updated_at);
      }
    });
    conversationList.appendChild(item);
  }
}

// --- Opening and viewing a conversation ---
async function fetchAndRenderMessages(sessionId) {
  console.log("[DEBUG] fetchAndRenderMessages called for:", sessionId);
  const responseData = await authedFetch(`/agent/conversations/${sessionId}/messages`);
  console.log("[DEBUG] responseData:", responseData);
  if (sessionId !== activeSessionId) { console.log("[DEBUG] session changed, aborting"); return null; }

  agentMessages.innerHTML = "";
  lastMsgSender = null;
  lastMsgTime = 0;
  lastMsgAuthor = null;

  if (responseData) {
    const messages = responseData.messages || [];
    console.log("[DEBUG] messages count:", messages.length);
    const pinnedMessages = messages.filter(m => m.is_pinned);

    let lastDateStr = null;
    for (const msg of messages) {
      console.log("[DEBUG] rendering msg:", msg.sender, msg.content?.substring(0, 30));
      const dateObj = new Date(msg.created_at);
      const dateStr = dateObj.toLocaleDateString();
      if (dateStr !== lastDateStr) {
        const dateDiv = document.createElement("div");
        dateDiv.className = "date-separator";

        const todayStr = new Date().toLocaleDateString();
        const yesterdayDate = new Date();
        yesterdayDate.setDate(yesterdayDate.getDate() - 1);
        const yesterdayStr = yesterdayDate.toLocaleDateString();

        if (dateStr === todayStr) dateDiv.textContent = "Today";
        else if (dateStr === yesterdayStr) dateDiv.textContent = "Yesterday";
        else dateDiv.textContent = dateObj.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'short', day: 'numeric' });

        agentMessages.appendChild(dateDiv);
        lastDateStr = dateStr;
      }
      appendMessage(msg.sender, msg.content, msg.created_at, msg.sender === "agent_internal", msg.id, msg.author_username, msg.author_role, msg.is_pinned);
    }

    updatePinnedMessageUI(pinnedMessages);
  } else {
    console.log("[DEBUG] responseData is null/falsy - auth failed or network error");
  }
  return responseData;
}

async function openConversation(sessionId, customerEmail, shortId, isResolved, updatedAt) {
  if (activeSessionId && activeSessionId !== sessionId) {
    drafts[activeSessionId] = agentInput.value;
  }
  hideCustomerTypingIndicator(); // clear any stale indicator from the previously-open conversation
  activeSessionId = sessionId;
  emptyState.classList.add("hidden");
  activeConversationEl.classList.remove("hidden");

  if (socket && socket.readyState === WebSocket.OPEN) {
    socket.send(JSON.stringify({ type: "view_conversation", session_id: sessionId }));
  }
  document.getElementById("collision-badge")?.classList.add("hidden");
  
  agentInput.value = drafts[sessionId] || "";
  agentInput.dispatchEvent(new Event("input"));

  conversationEmail.textContent = customerEmail || "Unknown Customer";
  const ticketIdBadge = document.getElementById("ticket-id-badge");
  if (ticketIdBadge) {
    const idStr = shortId || sessionId;
    ticketIdBadge.textContent = `#${idStr.substring(0, 8).toUpperCase()}`;
  }
  const webSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px; vertical-align:text-bottom;"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>`;
  const waSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px; vertical-align:text-bottom;"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"></path></svg>`;
  const igSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:4px; vertical-align:text-bottom;"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg>`;
  const platformsInfo = [
    { svg: webSvg, text: "via Web Widget" },
    { svg: waSvg, text: "via WhatsApp" },
    { svg: igSvg, text: "via Instagram" }
  ];
  const hash = shortId ? shortId.split('').reduce((a, b) => {a = ((a << 5) - a) + b.charCodeAt(0); return a & a}, 0) : 0;
  const platform = platformsInfo[Math.abs(hash) % platformsInfo.length];
  conversationSession.innerHTML = `${platform.svg} ${platform.text}`;
  
  const resolveTimeEl = document.getElementById("resolve-time");
  if (isResolved) {
    resolveBtn.textContent = "Resolved";
    resolveBtn.disabled = true;
    resolveBtn.classList.remove("btn-primary");
    if (updatedAt) {
      resolveTimeEl.textContent = `at ${formatSidebarTime(updatedAt)}`;
      resolveTimeEl.classList.remove("hidden");
    }
  } else {
    resolveBtn.textContent = "Mark resolved";
    resolveBtn.disabled = false;
    resolveBtn.classList.add("btn-primary");
    resolveTimeEl.classList.add("hidden");
  }

  // Clear sidebars immediately to prevent showing old data while loading
  clearCustomerSidebar();
  hideOrderPopup();
  resetTicketPropertiesBar();
  document.getElementById("slash-command-popup")?.classList.remove("active");
  
  // Reset input type to public (reply)
  const noteTypeSelect = document.getElementById("note-type-select");
  if (noteTypeSelect && noteTypeSelect.value !== "public") {
    noteTypeSelect.value = "public";
    noteTypeSelect.dispatchEvent(new Event('change'));
  }
  
  agentMessages.innerHTML = "<div class='loading-spinner'></div>";
  hasUnreadIndicator = false;
  agentInput.focus();

  await fetchAndRenderMessages(sessionId);

  fetchOrderContext(sessionId);
  loadTicketProperties(sessionId);
  loadConversations();
}

let lastMsgSender = null;
let lastMsgTime = 0;
let lastMsgAuthor = null;

let hasUnreadIndicator = false;

function injectUnreadIndicator() {
  if (hasUnreadIndicator) return;
  const div = document.createElement("div");
  div.className = "date-separator unread-indicator";
  div.style.color = "var(--accent-alert)";
  div.style.borderColor = "var(--line)";
  div.textContent = "New Messages";
  agentMessages.appendChild(div);
  hasUnreadIndicator = true;
}

function clearUnreadIndicator() {
  const indicators = agentMessages.querySelectorAll(".unread-indicator");
  indicators.forEach(el => el.remove());
  hasUnreadIndicator = false;
}

// --- Customer typing indicator (customer -> agent) ---
// Mirrors widget.js's showTypingIndicator/hideTypingIndicator, just shown
// as the customer's own bubble style instead of the agent/AI one.
function showCustomerTypingIndicator() {
  if (document.getElementById("customer-typing-wrapper")) return;
  const wrapper = document.createElement("div");
  wrapper.id = "customer-typing-wrapper";
  wrapper.className = "msg-content msg-content--human";
  wrapper.innerHTML = `
    <div class="msg msg--human typing-indicator">
      <span class="dot"></span><span class="dot"></span><span class="dot"></span>
    </div>
  `;
  agentMessages.appendChild(wrapper);
  scrollToBottom();
}

function hideCustomerTypingIndicator() {
  const wrapper = document.getElementById("customer-typing-wrapper");
  if (wrapper) {
    wrapper.remove();
  }
}


function scrollToBottom(force = false) {
  setTimeout(() => {
    agentMessages.scrollTop = agentMessages.scrollHeight;
  }, 50);
}

function updatePinnedMessageUI(pinnedMessages) {
  let pinnedContainer = document.getElementById("pinned-messages-wrapper");
  
  if (!pinnedMessages || pinnedMessages.length === 0) {
    if (pinnedContainer) pinnedContainer.remove();
    return;
  }
  
  if (!pinnedContainer) {
    pinnedContainer = document.createElement("div");
    pinnedContainer.id = "pinned-messages-wrapper";
    pinnedContainer.className = "pinned-messages-wrapper";
    
    // Insert before messages container (below order popup)
    const messagesContainer = document.getElementById("agent-messages");
    if (messagesContainer) {
      messagesContainer.parentNode.insertBefore(pinnedContainer, messagesContainer);
    }
  }
  
  let html = '';
  pinnedMessages.forEach((msg) => {
    let displayContent = msg.content || "";
    displayContent = displayContent.replace(/\[INTERNAL_IMAGE_DESC\][\s\S]*?\[\/INTERNAL_IMAGE_DESC\]/g, '');
    const isInternal = msg.sender === 'agent_internal' || displayContent.includes("INTERNAL NOTE");
    if (isInternal) displayContent = displayContent.replace(/^\*Internal Note:\* /, "");
    displayContent = displayContent.replace(/!\[.*?\]\(.*?\)/g, '[Image] '); // strip images
    displayContent = displayContent.replace(/\[(.*?)\]\(.*?\)/g, '$1'); // strip links
    displayContent = displayContent.replace(/[*_~`#>]/g, ''); // strip basic markdown
    displayContent = displayContent.replace(/<[^>]*>?/gm, '').trim().replace(/\s+/g, ' ');
    
    let senderName = msg.author_username;
    if (!senderName) {
      if (msg.sender === "customer" || msg.sender === "human") {
        senderName = document.getElementById("conversation-email").textContent || "Customer";
      } else {
        senderName = "You";
      }
    }
    
    html += `
      <div class="pinned-message ${isInternal ? 'pinned-message--internal' : ''}" data-id="${msg.id}" onclick="if (event.target.closest('.unpin-btn')) return; const el = document.querySelector('.msg-content[data-msg-id=\\'${msg.id}\\']'); if(el) el.scrollIntoView({behavior: 'smooth', block: 'center'});">
        <div class="pinned-message-content" style="display:flex; flex-direction:row; align-items:center; gap:8px; overflow:hidden;">
          <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0;"><line x1="12" x2="12" y1="17" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 11.24V6a3 3 0 0 0-6 0v5.24a2 2 0 0 1-1.11 1.31l-1.78.9A2 2 0 0 0 5 15.24Z"/></svg>
          <div style="overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
            <strong style="margin-right: 4px; font-weight:600;">${escapeHtml(senderName)}:</strong>
            <span class="pinned-message-text" style="display:inline; color: inherit; white-space:nowrap;">${escapeHtml(displayContent)}</span>
          </div>
        </div>
        <button class="unpin-btn" data-id="${msg.id}" title="Unpin" style="flex-shrink:0;">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
        </button>
      </div>
    `;
  });
  
  pinnedContainer.innerHTML = html;
}

// Dedicated fetch for pin/unpin — unlike authedFetch, this reads the
// response body even on a non-2xx status, so the 5-pin cap's 409 message
// actually reaches the agent instead of silently failing (authedFetch
// discards the body on any !response.ok).
async function togglePinMessage(messageId, newState) {
  if (!activeSessionId) return null;
  try {
    const response = await fetch(`${API_BASE}/agent/conversations/${activeSessionId}/pin`, {
      method: "POST",
      credentials: "include",
      headers: { "Content-Type": "application/json", "X-Wrennon-Client": "agent-dashboard" },
      body: JSON.stringify({ message_id: messageId, is_pinned: newState }),
    });
    if (response.status === 401) { logout(); return null; }
    const data = await response.json().catch(() => null);
    if (!response.ok) {
      alert((data && data.detail) || "Couldn't update pin.");
      return null;
    }
    return data;
  } catch (err) {
    console.error(err);
    return null;
  }
}

// Applies a pin/unpin result everywhere it's reflected: the pinned-messages
// banner AND the specific message bubble (indicator + dropdown label) if
// it's currently rendered. This is what was missing before — the old code
// only refreshed the conversation *list* after pinning, so the banner and
// bubble silently went stale until the agent reopened the conversation.
function syncPinnedUIAfterToggle(messageId, isPinnedNow, pinnedMessages) {
  updatePinnedMessageUI(pinnedMessages);

  const wrapper = document.querySelector(`[data-msg-id="${messageId}"]`);
  if (!wrapper) return;
  wrapper.dataset.pinned = isPinnedNow ? "1" : "0";

  const bubble = wrapper.querySelector(".msg");
  if (bubble) {
    bubble.classList.toggle("msg--pinned", isPinnedNow);
    const existingIndicator = bubble.querySelector(".msg-pin-indicator");
    if (isPinnedNow && !existingIndicator) {
      bubble.insertAdjacentHTML("afterbegin", `
        <span class="msg-pin-indicator" title="Pinned">
          <svg viewBox="0 0 24 24" width="10" height="10" fill="currentColor" stroke="none"><path d="M12 2a1 1 0 0 1 1 1v5.764l3.447 1.723A2 2 0 0 1 17.55 12.5H18a1 1 0 1 1 0 2h-5v6a1 1 0 1 1-2 0v-6H6a1 1 0 1 1 0-2h.45a2 2 0 0 1 1.103-1.013L11 8.764V3a1 1 0 0 1 1-1z"/></svg>
        </span>
      `);
    } else if (!isPinnedNow && existingIndicator) {
      existingIndicator.remove();
    }
  }

  const pinItem = wrapper.querySelector(".msg-action-pin");
  if (pinItem) {
    pinItem.dataset.pinned = isPinnedNow ? "1" : "0";
    const label = pinItem.querySelector(".msg-action-pin__label");
    if (label) label.textContent = isPinnedNow ? "Unpin" : "Pin";
  }
}

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && !activeConversationEl.classList.contains("hidden")) {
    clearUnreadIndicator();
  }
});

function appendMessage(sender, content, isoString = new Date().toISOString(), isInternal = false, msgId = null, author_username = null, author_role = null, isPinned = false) {
  if (!isInternal) {
    extractAndShowCustomerDetails(content);
  }
  
  if (document.hidden) {
    injectUnreadIndicator();
  }

  const timestamp = new Date(isoString).getTime();
  const actualSender = isInternal ? "agent" : sender;
  const currentAuthor = (actualSender === "agent") ? (author_username || localStorage.getItem("agent_username") || "Agent").toLowerCase() : null;
  
  let isGrouped = (sender === lastMsgSender && currentAuthor === lastMsgAuthor && (timestamp - lastMsgTime < 60000) && sender !== "system");
  
  if (isInternal) {
    isGrouped = false; // Never group internal notes
  }
  
  if (!isGrouped) {
    lastMsgSender = sender;
    lastMsgAuthor = currentAuthor;
  }
  lastMsgTime = timestamp;

  const contentWrapper = document.createElement("div");
  contentWrapper.className = `msg-content msg-content--${actualSender}${isGrouped ? ' msg-content--grouped' : ''}${isInternal ? ' msg-content--internal' : ''}`;
  contentWrapper.style.display = "flex";
  contentWrapper.style.flexDirection = "column";
  if (msgId) contentWrapper.dataset.msgId = msgId;
  contentWrapper.dataset.pinned = isPinned ? "1" : "0";

  const div = document.createElement("div");
  div.className = `msg msg--${actualSender}${isInternal ? ' msg--internal' : ''}`;
  div.setAttribute("role", "listitem");
  
  let nameHtml = "";
  if (actualSender === "agent" && !isGrouped) {
    const storedName = author_username || "Agent";
    const displayName = storedName.toUpperCase();
    
    const storedRole = author_role || "agent";
    const displayRole = storedRole.toUpperCase();
    
    if (isInternal) {
      const badgeHtml = `<span style="background: var(--accent-alert); color: white; padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-left: 6px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; display: inline-block; vertical-align: middle;">${displayRole}</span>`;
      nameHtml = `<div class="msg-name" style="display: flex; align-items: center; margin-bottom: 6px; font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 11px; font-weight: 600; color: var(--ink); opacity: 0.9; letter-spacing: 0.05em; text-transform: uppercase;"><span style="font-weight: 800; margin-right: 4px; color: var(--accent-alert);">Note:</span> ${displayName}${badgeHtml}</div>`;
    } else {
      const badgeHtml = `<span style="background: rgba(255,255,255,0.2); border: 1px solid rgba(255,255,255,0.3); color: var(--bg-base); padding: 2px 6px; border-radius: 4px; font-size: 10px; margin-left: 6px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; display: inline-block; vertical-align: middle;">${displayRole}</span>`;
      nameHtml = `<div class="msg-name" style="display: flex; align-items: center; margin-bottom: 6px; font-family: 'JetBrains Mono', ui-monospace, monospace; font-size: 11px; font-weight: 600; color: var(--bg-base); opacity: 0.95; letter-spacing: 0.05em; text-transform: uppercase;">${displayName}${badgeHtml}</div>`;
    }
  }
  
  // Format message content
  let displayContent = content || "";
    
  // Feature: Hide internal image descriptions from agent UI
  displayContent = displayContent.replace(/\[INTERNAL_IMAGE_DESC\][\s\S]*?\[\/INTERNAL_IMAGE_DESC\]/g, '');
  
  // Feature: WhatsApp style replies
  let replyHtml = '';
  const replyMatch = displayContent.match(/^> \*\*Replying to:\*\*\n((?:> .*\n?)+)\n\n([\s\S]*)$/);
  if (replyMatch) {
    const quotedLines = replyMatch[1].split('\n').map(line => line.replace(/^> /, '')).join('\n').trim();
    displayContent = replyMatch[2];
    
    replyHtml = `
      <div class="msg-reply-bubble">
        <div class="msg-reply-author">Replied to</div>
        <div class="msg-reply-text">${escapeHtml(quotedLines)}</div>
      </div>
    `;
  }

  // Feature: Extract audio transcriptions to display as collapsible blocks
  let transcriptHtml = '';
  displayContent = displayContent.replace(/\(Transcript:\s*([\s\S]*?)\)/g, (match, p1) => {
    transcriptHtml += `<details style="margin-top: 8px; font-size: 0.85em; opacity: 0.8; background: rgba(0,0,0,0.05); padding: 6px; border-radius: 6px; cursor: pointer;"><summary style="font-weight: 500; opacity: 0.8; padding: 2px;">View Transcript</summary><div style="margin-top: 6px; font-family: ui-monospace, monospace; white-space: pre-wrap; padding: 4px; border-top: 1px solid rgba(0,0,0,0.1);">${escapeHtml(p1.trim())}</div></details>`;
    return '';
  });

  if (isInternal) {
    displayContent = displayContent.replace(/^\*Internal Note:\* /, "");
    div.innerHTML = nameHtml + replyHtml + renderMarkdown(displayContent) + transcriptHtml;
  } else {
    div.innerHTML = nameHtml + replyHtml + renderMarkdown(displayContent) + transcriptHtml;
  }

  if (isPinned) {
    div.classList.add("msg--pinned");
    div.insertAdjacentHTML("afterbegin", `
      <span class="msg-pin-indicator" title="Pinned">
        <svg viewBox="0 0 24 24" width="10" height="10" fill="currentColor" stroke="none"><path d="M12 2a1 1 0 0 1 1 1v5.764l3.447 1.723A2 2 0 0 1 17.55 12.5H18a1 1 0 1 1 0 2h-5v6a1 1 0 1 1-2 0v-6H6a1 1 0 1 1 0-2h.45a2 2 0 0 1 1.103-1.013L11 8.764V3a1 1 0 0 1 1-1z"/></svg>
      </span>
    `);
  }

  if (msgId) {
    let actionsHtml = `<div class="msg-dropdown-container">
      <button class="msg-dropdown-btn" title="Message options">
        <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
      </button>
      <div class="msg-dropdown-menu">
        <div class="msg-dropdown-item msg-action-reply" data-content="${escapeHtml(displayContent)}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 17 4 12 9 7"></polyline><path d="M20 18v-2a4 4 0 0 0-4-4H4"></path></svg> Reply
        </div>
        <div class="msg-dropdown-item msg-action-copy" data-content="${escapeHtml(displayContent)}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg> Copy
        </div>
        <div class="msg-dropdown-item msg-action-pin" data-id="${msgId}" data-pinned="${isPinned ? "1" : "0"}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" x2="12" y1="17" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 11.24V6a3 3 0 0 0-6 0v5.24a2 2 0 0 1-1.11 1.31l-1.78.9A2 2 0 0 0 5 15.24Z"/></svg> <span class="msg-action-pin__label">${isPinned ? "Unpin" : "Pin"}</span>
        </div>
        <div class="msg-dropdown-item msg-action-copilot" data-content="${escapeHtml(displayContent)}">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-sparkles"><path d="M9.937 15.5A2 2 0 0 0 8.5 14.063l-6.135-1.582a.5.5 0 0 1 0-.962L8.5 9.936A2 2 0 0 0 9.937 8.5l1.582-6.135a.5.5 0 0 1 .963 0L14.063 8.5A2 2 0 0 0 15.5 9.937l6.135 1.581a.5.5 0 0 1 0 .964L15.5 14.063a2 2 0 0 0-1.437 1.437l-1.582 6.135a.5.5 0 0 1-.963 0z"/><path d="M20 3v4"/><path d="M22 5h-4"/><path d="M4 17v2"/><path d="M5 18H3"/></svg> Ask Copilot
          </div>`;
    if (isInternal) {
      actionsHtml += `<div class="msg-dropdown-item msg-action-delete" data-id="${msgId}">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg> Delete note
        </div>`;
    }
    actionsHtml += `</div></div>`;
    div.innerHTML += actionsHtml;
  }
  contentWrapper.appendChild(div);

  if (sender !== "system") {
    const timeStr = formatTime(isoString);
    const ticks = (sender === "ai" || sender === "agent" || isInternal) ? `<span class="msg-ticks"><svg viewBox="0 0 512 512" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="44"><path d="M464 128L240 384l-96-96M144 384l-96-96M368 128L232 284"/></svg></span>` : "";
    const metaDiv = document.createElement("div");
    metaDiv.className = `msg-meta msg-meta--${actualSender}`;
    metaDiv.innerHTML = `<span>${timeStr}</span>${ticks}`;
    contentWrapper.appendChild(metaDiv);
  }

  agentMessages.appendChild(contentWrapper);
  scrollToBottom(sender === 'agent');
}

document.addEventListener("click", async (e) => {
  // Dropdown toggle logic
  if (!e.target.closest('.msg-dropdown-container')) {
    document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => {
      el.classList.remove('show');
      const msg = el.closest('.msg');
      if (msg) msg.style.zIndex = "";
      const content = el.closest('.msg-content');
      if (content) content.style.zIndex = "";
    });
  }
  const dropdownBtn = e.target.closest('.msg-dropdown-btn');
  if (dropdownBtn) {
    const menu = dropdownBtn.nextElementSibling;
    const isShowing = menu.classList.contains('show');
    document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => {
      el.classList.remove('show');
      const msg = el.closest('.msg');
      if (msg) msg.style.zIndex = "";
      const content = el.closest('.msg-content');
      if (content) content.style.zIndex = "";
    });
    if (!isShowing) {
      menu.classList.add('show');
      
      const msg = menu.closest('.msg');
      if (msg) msg.style.zIndex = "999999";
      
      const content = menu.closest('.msg-content');
      if (content) content.style.zIndex = "999999";
      
      const rect = menu.getBoundingClientRect();
      
      // Prevent going off right edge
      if (rect.right > window.innerWidth) {
        menu.style.right = '0';
        menu.style.left = 'auto';
      }
      
      // Prevent going off bottom edge
      if (rect.bottom > window.innerHeight - 80) {
        menu.style.top = 'auto';
        menu.style.bottom = '100%';
      } else {
        menu.style.top = '100%';
        menu.style.bottom = 'auto';
      }
    }
    return;
  }

  // Handle Dropdown Actions
  const copyBtn = e.target.closest(".msg-action-copy");
  if (copyBtn) {
    const content = copyBtn.dataset.content;
    navigator.clipboard.writeText(content);
    
    // Toast notification style update
    const originalHtml = copyBtn.innerHTML;
    copyBtn.innerHTML = `<svg viewBox="0 0 512 512" width="16" height="16" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="44"><path d="M464 128L240 384l-96-96M144 384l-96-96M368 128L232 284"/></svg> Copied!`;
    setTimeout(() => {
      copyBtn.innerHTML = originalHtml;
      document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => el.classList.remove('show'));
    }, 1500);
    return;
  }

  const replyBtn = e.target.closest(".msg-action-reply");
  if (replyBtn) {
    const content = replyBtn.dataset.content;
    
    // Show preview container
    const previewContainer = document.getElementById("reply-preview-container");
    const previewText = document.getElementById("reply-preview-text");
    if (previewContainer && previewText) {
       previewText.textContent = content;
       previewContainer.classList.remove("hidden");
       // Store the replied content so it can be used during send
       previewContainer.dataset.replyContent = content;
    }
    
    const input = document.getElementById("agent-message-input");
    if (input) {
      input.focus();
    }
    document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => el.classList.remove('show'));
    return;
  }

  const closeReplyBtn = e.target.closest("#close-reply-preview");
  if (closeReplyBtn) {
     const previewContainer = document.getElementById("reply-preview-container");
     if (previewContainer) {
         previewContainer.classList.add("hidden");
         previewContainer.removeAttribute("data-reply-content");
     }
     return;
  }

  const copilotBtn = e.target.closest(".msg-action-copilot");
  if (copilotBtn) {
    const content = copilotBtn.dataset.content;
    const input = document.getElementById("agent-message-input");
    
    const originalText = copilotBtn.innerHTML;
    copilotBtn.innerHTML = "Drafting...";
    
    if (input && activeSessionId) {
       input.disabled = true;
       // We cannot use await directly if the surrounding function isn't async.
       // The click listener is async? Let's check: document.addEventListener("click", async (e) => { ... })
       // Wait, the global click listener is async?
       authedFetch(`/copilot/suggest`, "POST", { ticket_id: activeSessionId, context_message: content })
         .then(res => {
           if (res && res.suggested_reply) {
              input.value = res.suggested_reply;
              input.focus();
           }
         })
         .catch(err => console.error("Copilot fail", err))
         .finally(() => {
           input.disabled = false;
           copilotBtn.innerHTML = originalText;
           document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => el.classList.remove('show'));
         });
    }
    return;
  }

  const deleteBtn = e.target.closest(".msg-action-delete");
  if (deleteBtn) {
    const msgId = deleteBtn.dataset.id;
    if (!msgId) return;
    if (!confirm("Are you sure you want to delete this internal note?")) return;
    
    const result = await authedFetch(`/agent/messages/${msgId}`, "DELETE");
    if (result) {
      const wrapper = document.querySelector(`[data-msg-id="${msgId}"]`);
      if (wrapper) wrapper.remove();
    } else {
      alert("Failed to delete note. You can only delete your own notes.");
    }
    document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => el.classList.remove('show'));
    return;
  }
  
  const pinBtn = e.target.closest(".msg-action-pin");
  if (pinBtn) {
    const msgId = pinBtn.dataset.id;
    if (!msgId || !activeSessionId) return;
    const currentlyPinned = pinBtn.dataset.pinned === "1";

    const result = await togglePinMessage(msgId, !currentlyPinned);
    if (result) {
      syncPinnedUIAfterToggle(msgId, result.is_pinned, result.pinned_messages);
    }
    document.querySelectorAll('.msg-dropdown-menu.show').forEach(el => el.classList.remove('show'));
    return;
  }

  const unpinBtn = e.target.closest(".unpin-btn");
  if (unpinBtn) {
    const msgId = unpinBtn.dataset.id;
    if (!msgId || !activeSessionId) return;

    const result = await togglePinMessage(msgId, false);
    if (result) {
      syncPinnedUIAfterToggle(msgId, result.is_pinned, result.pinned_messages);
    }
  }
});

// --- Sending a reply ---
// ── Feature 3: Slash Commands & Feature 7: Mentions Autocomplete ──
let MACROS = [];
async function loadMacros() {
  try {
    const data = await authedFetch("/agent/canned-responses");
    if (data && Array.isArray(data)) {
      MACROS = data.map(c => ({ cmd: c.shortcut, desc: c.title, text: c.body }));
    }
  } catch(e) {
    console.error("Failed to load macros", e);
  }
}

const AGENTS = [];
const AGENT_DIRECTORY = []; // [{username, full_name, role}] — same fetch, reused by the assignee dropdown

async function loadAgents() {
  const data = await authedFetch("/agent/list");
  if (data && Array.isArray(data)) {
    AGENTS.length = 0;
    AGENT_DIRECTORY.length = 0;
    for (const agent of data) {
      if (agent.role === "agent" || agent.role === "manager" || agent.role === "admin") {
        let title = agent.role.charAt(0).toUpperCase() + agent.role.slice(1);
        let display = agent.full_name || agent.username;
        AGENTS.push({ cmd: "@" + agent.username, desc: display + " (" + title + ")" });
        AGENT_DIRECTORY.push({ username: agent.username, full_name: agent.full_name, role: agent.role });
      }
    }
    renderAssigneeDropdown(); // refresh in case the dropdown was already open/rendered
  }
}
loadAgents();

let slashSelectedIndex = 0;
let currentPopupMode = null; // "macro" or "mention"

function renderSlashPopup(matches, mode) {
  const popup = document.getElementById("slash-command-popup");
  if (!popup) return;
  popup.innerHTML = "";
  currentPopupMode = mode;
  matches.forEach((m, idx) => {
    const div = document.createElement("div");
    div.className = `slash-item ${idx === slashSelectedIndex ? "selected" : ""}`;
    div.innerHTML = `
      <span class="slash-item__command">${m.cmd}</span>
      <span class="slash-item__desc">${m.desc}</span>
    `;
    div.addEventListener("click", () => {
      if (currentPopupMode === "mention") {
        const val = agentInput.value;
        const lastSpace = val.lastIndexOf(" ");
        if (lastSpace === -1) {
          agentInput.value = m.cmd + " ";
          agentInput.dispatchEvent(new Event("input"));
        } else {
          agentInput.value = val.substring(0, lastSpace + 1) + m.cmd + " ";
          agentInput.dispatchEvent(new Event("input"));
        }
      } else {
        agentInput.value = m.text;
        agentInput.dispatchEvent(new Event("input"));
      }
      popup.classList.remove("active");
      agentInput.focus();
    });
    popup.appendChild(div);
  });
}

function updateSlashSelection(items) {
  items.forEach((item, idx) => {
    if (idx === slashSelectedIndex) item.classList.add("selected");
    else item.classList.remove("selected");
  });
}

agentInput.addEventListener("input", (e) => {
  const val = agentInput.value;
  const popup = document.getElementById("slash-command-popup");
  if (!popup) return;
  
  // Look at the last word being typed
  const lastSpace = val.lastIndexOf(" ");
  const lastWord = lastSpace === -1 ? val : val.substring(lastSpace + 1);
  
  let matches = [];
  let mode = null;

  if (lastWord.startsWith("/")) {
    const query = lastWord.toLowerCase();
    matches = MACROS.filter(m => m.cmd.toLowerCase().startsWith(query));
    mode = "macro";
  } else if (lastWord.startsWith("@")) {
    const noteTypeSelect = document.getElementById("note-type-select");
    const isInternal = noteTypeSelect && noteTypeSelect.value === "internal";
    if (isInternal) {
      const query = lastWord.toLowerCase();
      matches = AGENTS.filter(m => m.cmd.toLowerCase().startsWith(query));
      mode = "mention";
    }
  }

  if (matches.length > 0) {
    slashSelectedIndex = 0;
    renderSlashPopup(matches, mode);
    popup.classList.add("active");
  } else {
    popup.classList.remove("active");
  }
});

agentSendBtn.addEventListener("click", sendAgentReply);
agentInput.addEventListener("keydown", (e) => {
  const popup = document.getElementById("slash-command-popup");
  if (popup && popup.classList.contains("active")) {
    const items = popup.querySelectorAll('.slash-item');
    if (e.key === "ArrowDown") {
      e.preventDefault();
      slashSelectedIndex = (slashSelectedIndex + 1) % items.length;
      updateSlashSelection(items);
      return;
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      slashSelectedIndex = (slashSelectedIndex - 1 + items.length) % items.length;
      updateSlashSelection(items);
      return;
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (items[slashSelectedIndex]) {
        items[slashSelectedIndex].click();
      }
      return;
    } else if (e.key === "Escape") {
      popup.classList.remove("active");
      return;
    }
  }

  if (e.key === "Enter" && !e.shiftKey) {
    e.preventDefault();
    sendAgentReply();
  }
});

// Catch-all: close the mention/macro popup on any click outside it or the
// input. The input-event handler above only closes it while typing; clicks
// elsewhere (send button, sidebar, another panel) previously left it stuck
// open indefinitely.
document.addEventListener("click", (e) => {
  const popup = document.getElementById("slash-command-popup");
  if (!popup || !popup.classList.contains("active")) return;
  if (e.target === agentInput || popup.contains(e.target)) return;
  popup.classList.remove("active");
});

async function handleAgentFileUpload(file, inputElement, uploadInputElement, autoSend = false, sendFunction = null) {
  if (!file) return;
  
  const originalPlaceholder = inputElement.placeholder;
  inputElement.placeholder = "Uploading...";
  inputElement.disabled = true;
  
  const formData = new FormData();
  formData.append("file", file);
  
  try {
    const response = await fetch(`${API_BASE}/chat/upload/${activeSessionId}`, {
      method: "POST",
      credentials: "include",
      headers: { "X-Wrennon-Client": "agent-dashboard" },
      body: formData
    });
    const data = await response.json();
    if (data.url) {
      let md = `[Document](${data.url})`;
      if (file.type.startsWith("image/")) md = `![Image](${data.url})`;
      else if (file.type.startsWith("audio/")) md = `[Audio](${data.url})`;
      else if (file.type.startsWith("video/")) md = `[Video](${data.url})`;
      
      inputElement.value = (inputElement.value + (inputElement.value ? " " : "") + md).trim();
      inputElement.dispatchEvent(new Event("input"));
      if (autoSend && sendFunction) {
        sendFunction();
      }
    }
  } catch (err) {
    console.error("Upload failed", err);
  } finally {
    inputElement.placeholder = originalPlaceholder;
    inputElement.disabled = false;
    inputElement.focus();
    if (uploadInputElement) uploadInputElement.value = "";
  }
}

const agentUploadBtn = document.getElementById("agent-upload-btn");
const agentFileUpload = document.getElementById("agent-file-upload");
if (agentUploadBtn && agentFileUpload) {
  agentUploadBtn.addEventListener("click", () => agentFileUpload.click());
  agentFileUpload.addEventListener("change", (e) => handleAgentFileUpload(e.target.files[0], agentInput, agentFileUpload, false, null));
}

const agentPhotoBtn = document.getElementById("agent-photo-btn");
const agentPhotoUpload = document.getElementById("agent-photo-upload");
if (agentPhotoBtn && agentPhotoUpload) {
  agentPhotoBtn.addEventListener("click", () => agentPhotoUpload.click());
  agentPhotoUpload.addEventListener("change", (e) => handleAgentFileUpload(e.target.files[0], agentInput, agentPhotoUpload, true, sendAgentReply));
}

const agentVoiceBtn = document.getElementById("agent-voice-btn");
const agentVoiceUpload = document.getElementById("agent-voice-upload");
// --- Agent Voice Recording Logic ---
let agentMediaRecorder;
let agentAudioChunks = [];
let agentIsRecording = false;

if (agentVoiceBtn) {
  agentVoiceBtn.addEventListener("click", async () => {
    if (!agentIsRecording) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
        agentMediaRecorder = new MediaRecorder(stream);
        agentAudioChunks = [];
        
        agentMediaRecorder.addEventListener("dataavailable", event => {
          agentAudioChunks.push(event.data);
        });
        
        agentMediaRecorder.addEventListener("stop", () => {
          const audioBlob = new Blob(agentAudioChunks, { type: 'audio/webm' });
          const file = new File([audioBlob], "voice_message.webm", { type: 'audio/webm' });
          handleAgentFileUpload(file, agentInput, null, true, sendAgentReply);
          
          // Stop all tracks
          stream.getTracks().forEach(track => track.stop());
        });
        
        agentMediaRecorder.start();
        agentIsRecording = true;
        agentVoiceBtn.style.color = "#EF4444";
        agentVoiceBtn.style.animation = "pulse-glow 1s infinite";
      } catch (err) {
        console.error("Error accessing microphone:", err);
        alert("Could not access microphone.");
      }
    } else {
      agentMediaRecorder.stop();
      agentIsRecording = false;
      agentVoiceBtn.style.color = "#9CA3AF";
      agentVoiceBtn.style.animation = "none";
    }
  });
}

const noteTypeSelect = document.getElementById("note-type-select");
const chatInputWrapper = document.getElementById("chat-input-wrapper");
const sendToggleBtn = document.getElementById("agent-send-toggle");
const sendTypeMenu = document.getElementById("send-type-menu");
const sendTypeOptions = document.querySelectorAll(".send-type-option");

if (sendToggleBtn && sendTypeMenu) {
  sendToggleBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    sendTypeMenu.classList.toggle("hidden");
  });

  document.addEventListener("click", (e) => {
    if (!sendTypeMenu.contains(e.target) && !sendToggleBtn.contains(e.target)) {
      sendTypeMenu.classList.add("hidden");
    }
  });

  sendTypeOptions.forEach(option => {
    option.addEventListener("click", () => {
      const type = option.getAttribute("data-type");
      noteTypeSelect.value = type;
      noteTypeSelect.dispatchEvent(new Event("change"));
      sendTypeMenu.classList.add("hidden");
      
      // Update checkmarks
      sendTypeOptions.forEach(opt => opt.querySelector(".check-icon").classList.add("hidden"));
      option.querySelector(".check-icon").classList.remove("hidden");
    });
  });
}

if (noteTypeSelect && chatInputWrapper) {
  function updatePlaceholder() {
    if (noteTypeSelect.value === "internal") {
      chatInputWrapper.classList.add("internal-mode");
      // Use the actual width of the input to determine if we should show the full message
      agentInput.placeholder = agentInput.clientWidth > 380 
        ? "Type internal note... (Use @ to tag, / for cmds)" 
        : "Type internal note...";
      document.getElementById("agent-send-btn").textContent = "Add Note";
    } else {
      chatInputWrapper.classList.remove("internal-mode");
      agentInput.placeholder = "Type a message...";
      document.getElementById("agent-send-btn").textContent = "Send";
    }
  }

  // Observe the input element's width to dynamically update placeholder
  // This handles both window resizing and sidebar toggling
  const resizeObserver = new ResizeObserver(() => {
    if (noteTypeSelect.value === "internal") {
      updatePlaceholder();
    }
  });
  resizeObserver.observe(agentInput);

  noteTypeSelect.addEventListener("change", () => {
    updatePlaceholder();
    agentInput.focus();
  });
}

document.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.key.toLowerCase() === "l") {
    e.preventDefault();
    if (noteTypeSelect) {
      noteTypeSelect.value = noteTypeSelect.value === "internal" ? "public" : "internal";
      noteTypeSelect.dispatchEvent(new Event("change"));
      
      // Update checkmarks visually for shortcut
      if (sendTypeOptions) {
        sendTypeOptions.forEach(opt => {
          if (opt.getAttribute("data-type") === noteTypeSelect.value) {
            opt.querySelector(".check-icon").classList.remove("hidden");
          } else {
            opt.querySelector(".check-icon").classList.add("hidden");
          }
        });
      }
    }
  }
});

const agentCopilotBtn = document.getElementById("agent-copilot-btn");
if (agentCopilotBtn) {
  agentCopilotBtn.addEventListener("click", async () => {
    if (!activeSessionId) return;
    
    const originalText = agentCopilotBtn.innerHTML;
    agentCopilotBtn.innerHTML = "Generating...";
    agentCopilotBtn.disabled = true;
    agentInput.disabled = true;

    try {
      const req = {
          ticket_id: activeSessionId
      };
      const res = await fetch(`${API_BASE}/copilot/suggest`, {
          method: 'POST',
          credentials: "include",
          headers: {
            "Content-Type": "application/json",
            "X-Wrennon-Client": "agent-dashboard",
          },
          body: JSON.stringify(req)
      });
      if (res.ok) {
        const data = await res.json();
        // Insert suggested draft into the input field
        agentInput.value = data.suggested_reply;
        agentInput.dispatchEvent(new Event("input"));
        
        // Render action buttons if any
        if (data.actions && data.actions.length > 0) {
            renderCopilotActions(data.actions);
        }
      }
    } catch (err) {
      console.error("Copilot failed", err);
    } finally {
      agentCopilotBtn.innerHTML = originalText;
      agentCopilotBtn.disabled = false;
      agentInput.disabled = false;
      agentInput.focus();
    }
  });
}

function renderCopilotActions(actions) {
    let actionContainer = document.getElementById('copilot-action-container');
    if (!actionContainer) {
        actionContainer = document.createElement('div');
        actionContainer.id = 'copilot-action-container';
        actionContainer.className = 'copilot-actions';
        actionContainer.style.display = 'flex';
        actionContainer.style.gap = '8px';
        actionContainer.style.marginTop = '8px';
        const inputRow = document.querySelector('.chat-input-row');
        inputRow.parentNode.insertBefore(actionContainer, inputRow.nextSibling);
    }
    
    actionContainer.innerHTML = '';
    actions.forEach(action => {
        const btn = document.createElement('button');
        btn.className = 'btn btn-secondary btn-sm';
        btn.innerHTML = `⚡ ${escapeHtml(action.label)}`;
        btn.onclick = async () => {
            btn.innerHTML = 'Executing...';
            btn.disabled = true;
            try {
                // Mock execution
                await new Promise(r => setTimeout(r, 1000));
                
                // Append action result to chat as an internal note
                const note = `[Copilot Action Executed] ${action.label}`;
                socket.send(JSON.stringify({ 
                    type: "new_message", 
                    session_id: activeSessionId,
                    message: `*Internal Note:* ${note}`,
                    is_internal: true
                }));
                
                actionContainer.innerHTML = '';
            } catch (err) {
                console.error("Action failed", err);
            }
        };
        actionContainer.appendChild(btn);
    });
}

function sendAgentReply() {
  let text = agentInput.value.trim();
  const previewContainer = document.getElementById("reply-preview-container");
  const isReplying = previewContainer && !previewContainer.classList.contains("hidden") && previewContainer.dataset.replyContent;
  
  if (!text && !isReplying) return;
  if (!activeSessionId || !socket || socket.readyState !== WebSocket.OPEN) return;

  const isInternal = noteTypeSelect && noteTypeSelect.value === "internal";
  
  if (isReplying) {
    const quotedText = previewContainer.dataset.replyContent.split('\n').map(line => `> ${line}`).join('\n');
    text = `> **Replying to:**\n${quotedText}\n\n` + text;
    previewContainer.classList.add("hidden");
    previewContainer.removeAttribute("data-reply-content");
  }
  
  socket.send(JSON.stringify({ type: "new_message", session_id: activeSessionId, message: text.trim(), is_internal: isInternal }));
  
  agentInput.value = "";
  drafts[activeSessionId] = ""; 
  agentInput.style.height = "44px";
  agentInput.style.overflowY = "hidden";
  document.getElementById("slash-command-popup")?.classList.remove("active");
}

// --- Order Context Popup ---
async function fetchOrderContext(sessionId) {
  const result = await authedFetch(`/agent/conversations/${sessionId}/order-context`);
  if (result) {
    if (result.order) {
      showOrderPopup(result.order, result.customer);
    } else {
      hideOrderPopup();
    }
    
    if (result.customer) {
      showCustomerSidebar(result.customer);
      if (sessionId === activeSessionId && result.customer.name) {
        conversationEmail.textContent = result.customer.name;
      }
    } else {
      clearCustomerSidebar();
    }
  } else {
    hideOrderPopup();
    clearCustomerSidebar();
  }
}

function showOrderPopup(order, customer) {
  const popup = document.getElementById('order-popup');
  const body = document.getElementById('order-popup-body');
  if (!popup || !body) return;
  
  const statusClass = `order-status-badge--${(order.status || '').toLowerCase()}`;
  
  const formatTime = (isoStr) => {
    if (!isoStr) return '';
    try {
      const d = new Date(isoStr);
      if (isNaN(d.getTime())) return isoStr;
      return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' }) + ', ' + d.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return isoStr;
    }
  };

  const statuses = ['placed', 'processing', 'shipped', 'delivered'];
  let currentStatus = (order.status || 'placed').toLowerCase();
  
  const baseTimelineEvents = [
    { status: 'placed', label: 'Order Placed', time: '', icon: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path>' },
    { status: 'processing', label: 'Processing', time: '', icon: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline>' },
    { status: 'shipped', label: 'Shipped', time: '', icon: '<circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>' },
    { status: 'delivered', label: 'Delivered', time: '', icon: '<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline>' },
  ];
  
  if (currentStatus === 'cancelled') {
      baseTimelineEvents[3] = { status: 'cancelled', label: 'Cancelled', time: '', icon: '<circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line>' };
  }

  const timelineEvents = baseTimelineEvents.map(baseEvt => {
      let time = '';
      if (order.timeline && Array.isArray(order.timeline)) {
          const matched = order.timeline.find(t => t.status === baseEvt.status);
          if (matched && matched.time) {
              time = formatTime(matched.time);
          }
      }
      return { ...baseEvt, time };
  });

  const currentStatusIndex = statuses.indexOf(currentStatus);

  let timelineHtml = timelineEvents.map((evt, i) => {
    const isCompleted = (order.timeline && Array.isArray(order.timeline)) 
        ? !!order.timeline.find(t => t.status === evt.status) 
        : (i <= currentStatusIndex);
    return { ...evt, isCompleted };
  }).reverse().map((evt, index, arr) => {
    const isLast = index === arr.length - 1;
    return `
      <div class="order-timeline-item ${!evt.isCompleted ? 'order-timeline-item--incomplete' : ''}">
        <div class="order-timeline-icon ${evt.isCompleted ? `order-timeline-icon--${evt.status}` : 'order-timeline-icon--incomplete'}">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${evt.icon}</svg>
        </div>
        ${!isLast ? '<div class="order-timeline-line"></div>' : ''}
        <div class="order-timeline-content">
          <div class="order-timeline-label">${evt.label}</div>
          ${evt.isCompleted ? `<div class="order-timeline-time">${evt.time}</div>` : ''}
        </div>
      </div>
    `;
  }).join('');

  const availableFields = [];
  
  availableFields.push({ label: 'Order ID', value: `#${escapeHtml(order.order_id)}` });
  availableFields.push({ label: 'Status', value: `<span class="order-status-badge ${statusClass}">${escapeHtml(order.status)}</span>` });
  
  if (order.items_count) {
      availableFields.push({ label: 'Items', value: `${escapeHtml(order.items_count)} items` });
  } else if (order.items && order.items.length) {
      availableFields.push({ label: 'Items', value: `${order.items.length} items` });
  }
  
  if (order.order_date) availableFields.push({ label: 'Date', value: escapeHtml(order.order_date) });
  if (order.total_amount) availableFields.push({ label: 'Total', value: escapeHtml(order.total_amount) });
  
  if ((order.status || '').toLowerCase() === 'shipped' || (order.status || '').toLowerCase() === 'delivered') {
      if (order.tracking_url || order.carrier) {
          let labelHtml = `<span style="display:flex; align-items:center;">Tracking ${order.carrier ? `<span style="margin-left: 6px; padding: 2px 4px; background: color-mix(in srgb, var(--ink) 8%, transparent); border-radius: 4px; font-family: var(--font-sans); font-size: 10px; font-weight: 600; color: var(--ink); text-transform: none; letter-spacing: normal;">${escapeHtml(order.carrier)}</span>` : ''}</span>`;
          let valueHtml = '';
          if (order.tracking_url) {
              valueHtml = `<div style="display: flex; align-items: center; gap: 4px; line-height: 1;"><a href="${escapeHtml(order.tracking_url)}" target="_blank" rel="noopener noreferrer" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 180px;">${escapeHtml(order.tracking_url)}</a><button class="icon-action-btn" style="padding: 2px; height: 18px; width: 18px; margin: 0; min-height: 0; min-width: 0;" onclick="navigator.clipboard.writeText('${escapeHtml(order.tracking_url)}')" title="Copy tracking URL"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg></button></div>`;
          } else {
              valueHtml = `<span style="color: var(--text-muted);">No tracking link</span>`;
          }
          availableFields.push({ 
              label: labelHtml, 
              value: valueHtml,
              span: 2
          });
      }
  }
  
  if (order.eta && (order.status || '').toLowerCase() !== 'delivered' && (order.status || '').toLowerCase() !== 'cancelled') {
      availableFields.push({ label: 'ETA', value: escapeHtml(order.eta) });
  }
  
  if (order.payment_method) {
      let paymentBadge = `<span style="margin-left: 6px; padding: 2px 4px; background: color-mix(in srgb, var(--ink) 8%, transparent); border-radius: 4px; font-family: var(--font-sans); font-size: 10px; font-weight: 600; color: var(--ink); text-transform: none; letter-spacing: normal;">${escapeHtml(order.payment_method)}</span>`;
      let labelHtml = `<span style="display:flex; align-items:center;">Payment ${paymentBadge}</span>`;
      let valueHtml = '';
      if (order.invoice_url) {
          valueHtml = `<div style="display: flex; align-items: center; gap: 4px; line-height: 1;"><a href="${escapeHtml(order.invoice_url)}" target="_blank" rel="noopener noreferrer" style="white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 180px;">View Invoice</a><button class="icon-action-btn" style="padding: 2px; height: 18px; width: 18px; margin: 0; min-height: 0; min-width: 0;" onclick="navigator.clipboard.writeText('${escapeHtml(order.invoice_url)}')" title="Copy invoice URL"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"></rect><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"></path></svg></button></div>`;
      } else {
          valueHtml = `<span style="color: var(--text-muted);">No invoice link</span>`;
      }
      availableFields.push({ 
          label: labelHtml, 
          value: valueHtml,
          span: 2
      });
  }
  if (order.shipping_method) availableFields.push({ label: 'Shipping', value: escapeHtml(order.shipping_method) });

  const fieldsToShow = availableFields.slice(0, 8);
  
  const fieldsHtml = fieldsToShow.map(f => {
      return `<div class="order-popup__field" ${f.span ? `style="grid-column: span ${f.span};"` : ''}><span class="order-popup__label">${f.label}</span><span class="order-popup__value">${f.value}</span></div>`;
  }).join('');

  body.innerHTML = `
    <div class="order-popup__details-col">
      ${fieldsHtml}
    </div>
    <div class="order-popup__timeline-col">
      ${timelineHtml}
    </div>
  `;
  popup.classList.remove('hidden');
  body.classList.remove('hidden');
  const toggleBtn = document.getElementById('order-popup-toggle');
  if (toggleBtn) toggleBtn.style.transform = '';
}

function hideOrderPopup() {
  const popup = document.getElementById('order-popup');
  if (popup) popup.classList.add('hidden');
}

// Toggle button for order popup
document.addEventListener('click', (e) => {
  const toggleBtn = e.target.closest('#order-popup-toggle');
  if (toggleBtn) {
    const body = document.getElementById('order-popup-body');
    if (body) {
      body.classList.toggle('hidden');
      toggleBtn.style.transform = body.classList.contains('hidden') ? 'rotate(180deg)' : '';
    }
  }
});

// --- Resolving a conversation ---
resolveBtn.addEventListener("click", async () => {
  if (!activeSessionId) return;
  const result = await authedFetch(`/agent/conversations/${activeSessionId}/resolve`, "POST");
  if (result) {
    resolveBtn.textContent = "Resolved";
    resolveBtn.disabled = true;
    resolveBtn.classList.remove("btn-primary");
    const resolveTimeEl = document.getElementById("resolve-time");
    if (resolveTimeEl) {
      resolveTimeEl.textContent = `at ${formatSidebarTime(new Date().toISOString())}`;
      resolveTimeEl.classList.remove("hidden");
    }
    loadConversations();
  }
});

// --- Helpers ---
async function authedFetch(path, method = "GET", body = null) {
  try {
    const options = {
      method,
      credentials: "include", // send the httpOnly access_token cookie
      headers: {
        // Required by the backend's CSRF check for cookie-authenticated
        // non-GET requests (see get_current_agent) — a cross-site form or
        // fetch can't add this header, so its presence proves the request
        // actually came from this app's own JS.
        "X-Wrennon-Client": "agent-dashboard",
      },
    };
    if (body) {
      options.headers["Content-Type"] = "application/json";
      options.body = JSON.stringify(body);
    }
    const response = await fetch(`${API_BASE}${path}`, options);
    if (response.status === 401) {
      logout();
      return null;
    }
    if (!response.ok) return null;
    return await response.json();
  } catch (err) {
    console.error(err);
    return null;
  }
}

function renderMarkdown(text) {
  const lines = text.split("\n");
  let html = "";
  let inList = false;
  let listTag = "ul";

  const closeList = () => {
    if (inList) {
      html += `</${listTag}>`;
      inList = false;
    }
  };

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) {
      closeList();
      continue;
    }

    const numbered = line.match(/^(\d+)[.)]\s+(.*)/);
    const bulleted = line.match(/^[-*]\s+(.*)/);

    if (numbered || bulleted) {
      const tag = numbered ? "ol" : "ul";
      if (!inList || listTag !== tag) {
        closeList();
        html += `<${tag}>`;
        inList = true;
        listTag = tag;
      }
      const content = numbered ? numbered[2] : bulleted[1];
      html += `<li>${inlineMarkdown(content)}</li>`;
    } else {
      closeList();
      html += `<p>${inlineMarkdown(line)}</p>`;
    }
  }
  closeList();
  return html;
}

function inlineMarkdown(text) {
  let escaped = escapeHtml(text);
  escaped = escaped.replace(/\[Audio\]\((https?:\/\/[^\)]+)\)/g, (match, url) => {
    const safeUrl = escapeAttr(url);
    const playerId = 'vp_' + Math.random().toString(36).substr(2, 9);
    return `<div class="voice-player" id="${playerId}" data-src="${safeUrl}">` +
      `<button class="voice-player__btn" aria-label="Play voice message" onclick="toggleVoicePlayer('${playerId}')">` +
        `<svg class="voice-player__icon-play" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>` +
        `<svg class="voice-player__icon-pause" width="18" height="18" viewBox="0 0 24 24" fill="currentColor" style="display:none"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>` +
      `</button>` +
      `<div class="voice-player__waveform">` +
        Array.from({length: 20}, (_, i) => `<span class="voice-player__bar" style="animation-delay:${i * 0.05}s; height:${Math.floor(Math.random() * 60) + 20}%"></span>`).join('') +
      `</div>` +
      `<span class="voice-player__time">0:00</span>` +
      `<audio preload="metadata" src="${safeUrl}" onloadedmetadata="const d = this.duration; if(d && d !== Infinity) { this.parentElement.querySelector('.voice-player__time').textContent = Math.floor(d/60) + ':' + Math.floor(d%60).toString().padStart(2, '0'); }"></audio>` +
    `</div>`;
  });
  escaped = escaped.replace(/\[Video\]\((https?:\/\/[^\)]+)\)/g, (match, url) => {
    return `<video controls src="${escapeAttr(url)}" style="max-width: 100%; display: block; margin: 8px 0; border-radius: 8px;"></video>`;
  });
  escaped = escaped.replace(/!\[.*?\]\((https?:\/\/[^\)]+)\)/g, (match, url) => {
    return `<img src="${escapeAttr(url)}" class="chat-lightbox-image" style="max-width: 250px; max-height: 250px; object-fit: cover; display: block; margin: 8px 0; border-radius: 8px; cursor: pointer;" onclick="openLightbox(this.src)" />`;
  });
  escaped = escaped.replace(/\[([^\]]+)\]\((https?:\/\/[^\)]+)\)/g, (match, linkText, url) => {
    return `<a href="${escapeAttr(url)}" target="_blank" rel="noopener noreferrer" style="color: var(--accent); text-decoration: underline;">${linkText}</a>`;
  });
  escaped = escaped.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
  escaped = escaped.replace(/@([a-zA-Z0-9_]+)/g, '<span class="agent-mention" style="color: var(--accent); font-weight: 600; background: var(--accent-glow); padding: 0 4px; border-radius: 4px;">@$1</span>');
  return escaped;
}

function escapeAttr(text) {
  // escapeHtml() (below) already neutralized & < > in the whole message
  // before these URL groups were captured out of it, but it does NOT
  // escape quote characters. These captured URLs get interpolated
  // straight into double-quoted HTML attributes (href/src/data-src), so
  // a URL containing a literal " could otherwise break out of the
  // attribute and inject arbitrary attributes/event handlers — this was
  // the actual exploit path (a crafted customer message could steal an
  // agent's JWT out of localStorage the moment the agent opened the
  // conversation). Closes that gap.
  return text.replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

// --- Voice Player Logic ---
function toggleVoicePlayer(playerId) {
  const container = document.getElementById(playerId);
  if (!container) return;
  const audio = container.querySelector('audio');
  const playIcon = container.querySelector('.voice-player__icon-play');
  const pauseIcon = container.querySelector('.voice-player__icon-pause');
  const timeEl = container.querySelector('.voice-player__time');
  const bars = container.querySelectorAll('.voice-player__bar');

  if (!audio._initialized) {
    audio.addEventListener('timeupdate', () => {
      const mins = Math.floor(audio.currentTime / 60);
      const secs = Math.floor(audio.currentTime % 60).toString().padStart(2, '0');
      timeEl.textContent = `${mins}:${secs}`;
      let pct = 0;
      if (audio.duration && audio.duration !== Infinity) {
        pct = audio.currentTime / audio.duration;
      }
      bars.forEach((bar, i) => {
        bar.style.opacity = (i / bars.length) <= pct ? '1' : '0.4';
      });
    });
    audio.addEventListener('ended', () => {
      playIcon.style.display = '';
      pauseIcon.style.display = 'none';
      container.classList.remove('voice-player--playing');
      bars.forEach(bar => bar.style.opacity = '0.4');
      const mins = Math.floor(audio.duration / 60);
      const secs = Math.floor(audio.duration % 60).toString().padStart(2, '0');
      timeEl.textContent = `${mins}:${secs}`;
    });
    audio.addEventListener('loadedmetadata', () => {
      const mins = Math.floor(audio.duration / 60);
      const secs = Math.floor(audio.duration % 60).toString().padStart(2, '0');
      timeEl.textContent = `${mins}:${secs}`;
    });
    audio._initialized = true;
  }

  // Pause all other players first
  document.querySelectorAll('.voice-player--playing').forEach(other => {
    if (other.id !== playerId) {
      const otherAudio = other.querySelector('audio');
      if (otherAudio) otherAudio.pause();
      other.classList.remove('voice-player--playing');
      other.querySelector('.voice-player__icon-play').style.display = '';
      other.querySelector('.voice-player__icon-pause').style.display = 'none';
    }
  });

  if (audio.paused) {
    audio.play().catch(err => {
      console.error("Audio playback error:", err);
      alert("Cannot play audio: " + err.message + "\nCheck if your browser supports playing this file.");
      playIcon.style.display = '';
      pauseIcon.style.display = 'none';
      container.classList.remove('voice-player--playing');
    });
    playIcon.style.display = 'none';
    pauseIcon.style.display = '';
    container.classList.add('voice-player--playing');
  } else {
    audio.pause();
    playIcon.style.display = '';
    pauseIcon.style.display = 'none';
    container.classList.remove('voice-player--playing');
  }
}

function formatTime(isoString) {
  const date = new Date(isoString);
  return date.toLocaleTimeString('en-US', { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Dhaka" });
}

function formatSidebarTime(isoString) {
  if (!isoString) return '';
  const date = new Date(isoString);
  const now = new Date();
  
  const isToday = date.getDate() === now.getDate() && date.getMonth() === now.getMonth() && date.getFullYear() === now.getFullYear();
  
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  const isYesterday = date.getDate() === yesterday.getDate() && date.getMonth() === yesterday.getMonth() && date.getFullYear() === yesterday.getFullYear();

  if (isToday) {
    return date.toLocaleTimeString('en-GB', { hour: "2-digit", minute: "2-digit", timeZone: "Asia/Dhaka" });
  } else if (isYesterday) {
    return 'Yesterday';
  } else {
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', timeZone: "Asia/Dhaka" });
  }
}

function logout() {
  // Best-effort: if this was triggered by an already-expired/invalid
  // session (e.g. the 4401 handler above), this call will itself 401 —
  // that's fine, the cookie will just expire on its own in that case.
  fetch(`${API_BASE}/agent/logout`, {
    method: "POST",
    credentials: "include",
    headers: { "X-Wrennon-Client": "agent-dashboard" },
  }).catch(() => {});

  localStorage.removeItem("agent_username");
  localStorage.removeItem("agent_role");
  localStorage.removeItem("agent_dp_url");
  
  const antiFlash = document.getElementById('anti-flash-style');
  if(antiFlash) antiFlash.remove();
  
  dashboard.classList.add("hidden");
  loginScreen.classList.remove("hidden");
  if (socket) socket.close();
}

// --- Auto Login ---
document.addEventListener("DOMContentLoaded", async () => {
  const savedUsername = localStorage.getItem("agent_username");
  const savedRole = localStorage.getItem("agent_role");
  const savedDp = localStorage.getItem("agent_dp_url");
  
  if (savedUsername) {
    // We make a test request to see if we're authenticated, since the token is an HTTP-only cookie.
    const checkAuth = await authedFetch("/agent/conversations/needs-attention");
    
    if (checkAuth) {
      loginScreen.classList.add("hidden");
      dashboard.classList.remove("hidden");
      
      if (savedDp) {
        const dpEl = document.getElementById("agent-profile-dp");
        if (dpEl) dpEl.src = savedDp;
      }
      
      if (savedRole === "manager" || savedRole === "admin") {
        const adminBtn = document.getElementById("admin-dashboard-btn");
        if (adminBtn) {
          adminBtn.classList.remove("hidden");
          adminBtn.addEventListener("click", () => {
            window.location.href = "/agent/admin_dashboard.html?v=" + new Date().getTime();
          });
        }
      }
      
      connectSocket();
      loadConversations();
      loadAgents(); // same fix as the fresh-login path above — this is the
                     // "already logged in, cookie still valid" restore path.
    } else {
      logout();
    }
  }
});

// --- Resizable Sidebar Logic ---
const resizer = document.getElementById("resizer");
const sidebar = document.getElementById("sidebar");
let isResizing = false;

if (resizer && sidebar) {
  resizer.addEventListener("mousedown", (e) => {
    isResizing = true;
    document.body.style.cursor = "col-resize";
    e.preventDefault(); // Prevent text selection
  });

  document.addEventListener("mousemove", (e) => {
    if (!isResizing) return;
    const newWidth = e.clientX - sidebar.getBoundingClientRect().left;
    if (newWidth >= 200 && newWidth <= window.innerWidth * 0.7) {
      sidebar.style.width = `${newWidth}px`;
    }
  });

  document.addEventListener("mouseup", () => {
    if (isResizing) {
      isResizing = false;
      document.body.style.cursor = "default";
    }
  });
}

// --- Tab switching logic for theme dropdown ---
document.querySelectorAll('.theme-tab').forEach(tab => {
  tab.addEventListener('click', (e) => {
    e.stopPropagation(); // prevent dropdown from closing
    const targetId = tab.getAttribute('data-target');
    const dropdown = tab.closest('.theme-dropdown-menu');
    
    // Remove active class from all tabs
    dropdown.querySelectorAll('.theme-tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    
    // Hide all contents
    dropdown.querySelectorAll('.theme-tab-content').forEach(c => c.classList.add('hidden'));
    
    // Show target content
    const targetContent = dropdown.querySelector('#' + targetId);
    if(targetContent) targetContent.classList.remove('hidden');
  });
});

// --- Lightbox Logic ---
let lightboxImages = [];
let currentLightboxIndex = 0;

window.openLightbox = function(src) {
  const imgs = Array.from(document.querySelectorAll('.chat-lightbox-image'));
  if (imgs.length === 0) return;
  
  lightboxImages = imgs.map(img => img.src);
  currentLightboxIndex = lightboxImages.indexOf(src);
  if (currentLightboxIndex === -1) currentLightboxIndex = 0;
  
  let lightbox = document.getElementById('chat-lightbox-overlay');
  if (!lightbox) {
    lightbox = document.createElement('div');
    lightbox.id = 'chat-lightbox-overlay';
    lightbox.className = 'chat-lightbox-overlay';
    lightbox.innerHTML = `
      <div class="chat-lightbox-close" onclick="closeLightbox()">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </div>
      <div class="chat-lightbox-nav prev" onclick="lightboxPrev(event)">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"></polyline></svg>
      </div>
      <div class="chat-lightbox-img-wrapper">
        <img id="chat-lightbox-img" src="" />
      </div>
      <div class="chat-lightbox-nav next" onclick="lightboxNext(event)">
        <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"></polyline></svg>
      </div>
    `;
    
    lightbox.addEventListener('click', (e) => {
      if (e.target === lightbox || e.target.classList.contains('chat-lightbox-img-wrapper')) closeLightbox();
    });
    
    const container = document.getElementById('conversation-view') || document.body;
    container.appendChild(lightbox);
    document.addEventListener('keydown', handleLightboxKeydown);
  }
  
  updateLightbox();
  lightbox.style.display = 'flex';
  setTimeout(() => lightbox.style.opacity = '1', 10);
};

window.closeLightbox = function() {
  const lightbox = document.getElementById('chat-lightbox-overlay');
  if (lightbox) {
    lightbox.style.opacity = '0';
    setTimeout(() => {
      lightbox.style.display = 'none';
    }, 200);
  }
};

window.lightboxNext = function(e) {
  if (e) e.stopPropagation();
  if (currentLightboxIndex < lightboxImages.length - 1) {
    currentLightboxIndex++;
    updateLightbox();
  }
};

window.lightboxPrev = function(e) {
  if (e) e.stopPropagation();
  if (currentLightboxIndex > 0) {
    currentLightboxIndex--;
    updateLightbox();
  }
};

function updateLightbox() {
  const imgEl = document.getElementById('chat-lightbox-img');
  if (!imgEl) return;
  imgEl.src = lightboxImages[currentLightboxIndex];
  
  const prevBtn = document.querySelector('.chat-lightbox-nav.prev');
  const nextBtn = document.querySelector('.chat-lightbox-nav.next');
  if (prevBtn) prevBtn.style.visibility = (currentLightboxIndex > 0) ? 'visible' : 'hidden';
  if (nextBtn) nextBtn.style.visibility = (currentLightboxIndex < lightboxImages.length - 1) ? 'visible' : 'hidden';
}

function handleLightboxKeydown(e) {
  const lightbox = document.getElementById('chat-lightbox-overlay');
  if (!lightbox || lightbox.style.display === 'none') return;
  
  if (e.key === 'Escape') closeLightbox();
  if (e.key === 'ArrowRight') lightboxNext();
  if (e.key === 'ArrowLeft') lightboxPrev();
}

// ── Customer Details Logic ──

let currentlyShowingCustomerId = null;

function extractAndShowCustomerDetails(text) {
  // Handled entirely by the backend now; UI auto-updates on fetchOrderContext.
}

function showCustomerSidebar(customer) {
  currentlyShowingCustomerId = customer.id;
  const sidebar = document.getElementById("customer-sidebar");
  const content = document.getElementById("customer-sidebar-content");
  
  if (!sidebar || !content) return;
  
  const interactions = [
    { action: `Conversation with ${customer.name || 'Agent'}`, time: 'Active now', status: 'O', highlight: true }
  ];

  const totalOrders = customer.total_orders || 0;
  const recentOrderStr = customer.recent_order || '12965';
  let recentOrderNum = parseInt(recentOrderStr.toString().replace(/\D/g, ''));
  if (isNaN(recentOrderNum)) recentOrderNum = 12965;
  
  const cId = customer.id || "CUST";
  let hash = 0;
  for (let c = 0; c < cId.length; c++) {
    hash = ((hash << 5) - hash) + cId.charCodeAt(c);
    hash |= 0;
  }
  const mulberry32 = (a) => {
      return function() {
        var t = a += 0x6D2B79F5;
        t = Math.imul(t ^ t >>> 15, t | 1);
        t ^= t + Math.imul(t ^ t >>> 7, t | 61);
        return ((t ^ t >>> 14) >>> 0) / 4294967296;
      }
  }
  const prng = mulberry32(Math.abs(hash));
  
  const formatDate = (d) => {
       const hour = d.getHours();
       const minute = d.getMinutes();
       const ampm = hour >= 12 ? 'PM' : 'AM';
       const hour12 = hour % 12 || 12;
       const month = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][d.getMonth()];
       const day = String(d.getDate()).padStart(2, '0');
       return `${month} ${day}, ${hour12}:${String(minute).padStart(2, '0')} ${ampm}`;
  };

  const possibleActions = [
      { action: 'Left a 5-star review', status: 'empty' },
      { action: 'Added items to Wishlist', status: 'empty' },
      { action: 'Contacted support via Email', status: 'P' },
      { action: 'Requested a return (RMA)', status: 'empty' },
      { action: 'Browsed Help Center articles', status: 'empty' },
      { action: 'Subscribed to Newsletter', status: 'empty' },
      { action: 'Used a discount code', status: 'empty' },
      { action: 'Reported a delayed shipment', status: 'O' }
  ];

  let currentPastOrderId = (recentOrderNum * 10000) + Math.floor(prng() * 9000);
  const currentDate = new Date(2026, 7, 8, 9, 5); // Aug 08, 9:05 AM
  
  if (totalOrders > 0) {
    interactions.push({ action: `Ordered #${recentOrderStr}`, time: formatDate(currentDate), status: 'empty' });
    
    for (let i = 1; i < totalOrders; i++) {
       currentDate.setDate(currentDate.getDate() - (10 + Math.floor(prng() * 30)));
       currentDate.setHours(8 + Math.floor(prng() * 12), Math.floor(prng() * 60));
       
       currentPastOrderId -= (1500 + Math.floor(prng() * 3500));
       
       interactions.push({ action: `Ordered #${currentPastOrderId}`, time: formatDate(currentDate), status: 'empty' });
       
       const numInteractions = Math.floor(prng() * 2) + 1;
       for (let j = 0; j < numInteractions; j++) {
           const actObj = possibleActions[Math.floor(prng() * possibleActions.length)];
           const interactionDate = new Date(currentDate);
           interactionDate.setDate(interactionDate.getDate() - Math.floor(prng() * 5));
           interactions.push({ action: actObj.action, time: formatDate(interactionDate), status: actObj.status });
       }
    }
  }

  currentDate.setDate(currentDate.getDate() - (30 + Math.floor(prng() * 60)));
  interactions.push({ action: 'Account created / Sign up', time: formatDate(currentDate), status: 'S' });

  window.addCustomerNote = function(inputElem, event) {
    if (event.key !== 'Enter') return;
    const text = inputElem.value.trim();
    if (!text) return;
    inputElem.value = '';
    const container = inputElem.parentElement.previousElementSibling;
    const noteDiv = document.createElement('div');
    noteDiv.style.cssText = 'background: color-mix(in srgb, var(--accent) 8%, transparent); padding: 6px 10px; border-radius: 6px; font-size: 12px; color: var(--ink); border: 1px solid color-mix(in srgb, var(--accent) 20%, transparent); display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; line-height: 1.4; margin-bottom: 6px;';
    const escapedText = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    noteDiv.innerHTML = `
      <span style="flex:1;word-break:break-word;">${escapedText}</span>
      <button onclick="this.parentElement.remove()" style="background:none;border:none;cursor:pointer;color:var(--text-muted);padding:2px;margin:-2px;border-radius:4px;display:flex;align-items:center;justify-content:center;transition:color 0.2s, background 0.2s;" onmouseover="this.style.color='var(--danger)';this.style.background='color-mix(in srgb, var(--danger) 10%, transparent)'" onmouseout="this.style.color='var(--text-muted)';this.style.background='none'">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    `;
    container.appendChild(noteDiv);
  };

  const getStatusIcon = (item) => {
    const act = item.action.toLowerCase();
    let bgClass = "bg-gray";
    if (item.status === 'O') bgClass = "bg-red";
    if (item.status === 'P') bgClass = "bg-blue";
    if (item.status === 'empty') bgClass = "border-only";
    
    let iconSvg = '';
    if (act.includes('conversation') || act.includes('chat')) {
      iconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>`;
    }
    else if (act.includes('order') || act.includes('receipt')) {
      iconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>`;
    }
    else if (act.includes('email') || act.includes('address')) {
      iconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>`;
    }
    else if (act.includes('article') || act.includes('viewed')) {
      iconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>`;
    }
    else {
      iconSvg = `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>`;
    }

    if (bgClass === "border-only") {
      return `<div class="status-icon" style="background:transparent; border:1px solid var(--line); color:var(--text-muted); width:20px; height:20px; border-radius:4px;">${iconSvg}</div>`;
    }

    return `<div class="status-icon ${bgClass}">${iconSvg}</div>`;
  };

  content.innerHTML = `
    <div class="customer-details-box">
      <div class="customer-profile-compact">
        <div class="customer-profile__avatar-small">
          <img src="https://i.pravatar.cc/150?u=${encodeURIComponent(customer.email || customer.id)}" alt="Avatar" onerror="this.src='/agent/images/default-avatar.png?v=2'">
        </div>
        <div class="customer-profile-info">
          <div style="display:flex; flex-direction:column; gap:2px; flex:1; overflow:hidden;">
            <div class="customer-profile__name" style="display:block; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">${escapeHtml(customer.name)}</div>
            <div class="customer-profile__id" style="display:inline-block; width:fit-content; margin-top:2px; font-size:11px; color:var(--text-muted); font-weight:normal;">#${escapeHtml(customer.id)}</div>
          </div>
          <div class="customer-profile-actions" style="margin-top:2px;">
             <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </div>
      </div>
    </div>
    
    <div class="customer-contact-list">
      <div class="contact-item">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"></path><polyline points="22,6 12,13 2,6"></polyline></svg>
        <span class="value link">${escapeHtml(customer.email)}</span>
      </div>
      <div class="contact-item">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path></svg>
        <span class="value">${escapeHtml(customer.phone || '+1 (415) 123-2399')}</span>
      </div>
      <div class="contact-item">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="2" y1="12" x2="22" y2="12"></line><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"></path></svg>
        <span class="value">United States</span>
      </div>
      <div class="contact-item">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
        <span class="value">Total Orders: <strong>${customer.total_orders || 0}</strong></span>
      </div>
      <div class="contact-item tags">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg>
        <div class="customer-tags-inline">
          ${(customer.tags || ['premium', 'priority shopping']).map(tag => `<span class="customer-tag">${escapeHtml(tag.toLowerCase())}</span>`).join('')}
        </div>
      </div>
      <div class="contact-item note" style="flex-direction: column; align-items: flex-start; margin-top: -4px; width: 100%;">
        <div id="saved-notes-container" style="display: flex; flex-direction: column; width: 100%;"></div>
        <div style="display: flex; gap: 10px; width: 100%; align-items: center;">
          <svg style="flex-shrink: 0; color: var(--text-muted);" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path></svg>
          <input type="text" class="note-input-field" placeholder="Add user notes..." style="flex: 1; border: 1px solid color-mix(in srgb, var(--line) 80%, transparent); border-radius: 6px; background: color-mix(in srgb, var(--bg-surface) 50%, transparent); color: var(--ink); font-size: 13px; outline: none; padding: 8px 12px; transition: border-color 0.2s;" onfocus="this.style.borderColor='var(--accent)'" onblur="this.style.borderColor='color-mix(in srgb, var(--line) 80%, transparent)'" onkeydown="window.addCustomerNote(this, event)">
        </div>
      </div>
    </div>

    <div class="interactions-section">
      <div class="interactions-header">
        <div class="customer-section__title">Interactions</div>
        <div class="interactions-actions">
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" title="Wishlist"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" title="Cart"><circle cx="9" cy="21" r="1"></circle><circle cx="20" cy="21" r="1"></circle><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path></svg>
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" title="Filter"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"></polygon></svg>
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" title="Refresh"><polyline points="23 4 23 10 17 10"></polyline><polyline points="1 20 1 14 7 14"></polyline><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
           <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </div>
      </div>
      <div class="interactions-timeline-compact">
        ${interactions.map((item, index) => `
          <div class="timeline-item-compact ${item.highlight ? 'highlight' : ''}">
            <div class="timeline-status-col">
               ${getStatusIcon(item)}
               ${index < interactions.length - 1 ? '<div class="timeline-line"></div>' : ''}
            </div>
            <div class="timeline-content">
              <div class="timeline-action">${escapeHtml(item.action)}</div>
              <div class="timeline-time">${escapeHtml(item.time)}</div>
            </div>
          </div>
        `).join('')}
      </div>
    </div>
    </div>
  `;
  
  sidebar.classList.remove("hidden");
  
  const toggleBtn = document.getElementById("customer-sidebar-toggle");
  if (toggleBtn) {
    const avatarUrl = `https://i.pravatar.cc/150?u=${encodeURIComponent(customer.email || customer.id)}`;
    toggleBtn.innerHTML = `<img src="${avatarUrl}" style="width: 100%; height: 100%; border-radius: 50%; object-fit: cover;" alt="Customer Details" onerror="this.src='/agent/images/default-avatar.png?v=2'">`;
    toggleBtn.style.padding = "2px";
    toggleBtn.style.borderRadius = "50%";
  }
}

function hideCustomerSidebar() {
  const sidebar = document.getElementById("customer-sidebar");
  if (sidebar) {
    sidebar.classList.add("hidden");
  }
}

function clearCustomerSidebar() {
  hideCustomerSidebar();
  currentlyShowingCustomerId = null;
  
  const toggleBtn = document.getElementById("customer-sidebar-toggle");
  if (toggleBtn) {
    toggleBtn.innerHTML = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>`;
    toggleBtn.style.padding = "0";
    toggleBtn.style.borderRadius = "10px";
  }
}

// Toggle Sidebar Buttons
(function setupSidebarToggles() {
  const toggleBtn = document.getElementById("customer-sidebar-toggle");
  const closeBtn = document.getElementById("customer-sidebar-close");
  const sidebar = document.getElementById("customer-sidebar");
  
  if (toggleBtn) {
    toggleBtn.addEventListener("click", () => {
      if (sidebar && sidebar.classList.contains("hidden")) {
        // If no customer is detected yet, do nothing. Backend handles context auto-open.
        if (!currentlyShowingCustomerId) {
          // Do nothing
        } else {
          sidebar.classList.remove("hidden");
        }
      } else {
        hideCustomerSidebar();
      }
    });
  }
  
  // Auto-hide customer sidebar when screen becomes too small
  window.addEventListener("resize", () => {
    if (window.innerWidth <= 820) {
      hideCustomerSidebar();
    }
  });
  if (closeBtn) {
    closeBtn.addEventListener("click", hideCustomerSidebar);
  }
})();

// ── Ticket Properties Bar: priority / assignee / tags ──
// State for whichever conversation is currently open. Kept separate from
// the customer-sidebar state above (currentlyShowingCustomerId) since a
// conversation can have properties even when no customer record was
// matched yet (order-context lookup can fail independently).
let currentTicketProperties = { priority: "normal", tags: [], assigned_agent: null };

const PRIORITY_LABELS = { low: "Low", normal: "Normal", high: "High", urgent: "Urgent" };

function initials(name) {
  if (!name) return "?";
  const parts = name.trim().split(/\s+/);
  return parts.length > 1
    ? (parts[0][0] + parts[parts.length - 1][0]).toUpperCase()
    : name.slice(0, 2).toUpperCase();
}

function renderPriorityBadge(priority) {
  const badge = document.getElementById("priority-badge");
  const label = document.getElementById("priority-label");
  if (!badge || !label) return;
  const p = PRIORITY_LABELS[priority] ? priority : "normal";
  badge.className = `priority-badge priority-badge--${p}`;
  badge.querySelector(".priority-dot").className = `priority-dot priority-dot--${p}`;
  label.textContent = PRIORITY_LABELS[p];

  document.querySelectorAll("#priority-dropdown .tp-dropdown__item").forEach(item => {
    item.classList.toggle("tp-dropdown__item--active", item.dataset.priority === p);
  });
}

function renderAssigneeBadge(username) {
  const avatar = document.getElementById("assignee-avatar");
  const label = document.getElementById("assignee-label");
  if (!avatar || !label) return;
  if (!username) {
    avatar.textContent = "?";
    avatar.className = "assignee-avatar assignee-avatar--unassigned";
    label.textContent = "Unassigned";
    return;
  }
  const entry = AGENT_DIRECTORY.find(a => a.username === username);
  const display = entry ? (entry.full_name || entry.username) : username;
  avatar.textContent = initials(display);
  avatar.className = "assignee-avatar";
  label.textContent = display;
}

function renderAssigneeDropdown() {
  const dropdown = document.getElementById("assignee-dropdown");
  if (!dropdown) return;
  const current = currentTicketProperties.assigned_agent;
  const unassignedActive = !current ? "tp-dropdown__item--active" : "";
  let html = `<button class="tp-dropdown__item ${unassignedActive}" data-assignee=""><span class="assignee-avatar assignee-avatar--unassigned" style="width:18px;height:18px;font-size:9px;">?</span>Unassigned</button>`;
  for (const a of AGENT_DIRECTORY) {
    const active = a.username === current ? "tp-dropdown__item--active" : "";
    const display = a.full_name || a.username;
    html += `<button class="tp-dropdown__item ${active}" data-assignee="${escapeHtml(a.username)}"><span class="assignee-avatar" style="width:18px;height:18px;font-size:9px;">${escapeHtml(initials(display))}</span>${escapeHtml(display)}</button>`;
  }
  dropdown.innerHTML = html;
}

function renderTagChips(tags) {
  const container = document.getElementById("tag-chips");
  if (!container) return;
  container.innerHTML = (tags || []).map(tag => `
    <span class="tp-tag-chip">
      ${escapeHtml(tag)}
      <button class="tp-tag-chip__remove" data-tag="${escapeHtml(tag)}" aria-label="Remove tag ${escapeHtml(tag)}">
        <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
      </button>
    </span>
  `).join("");
}

function resetTicketPropertiesBar() {
  currentTicketProperties = { priority: "normal", tags: [], assigned_agent: null };
  renderPriorityBadge("normal");
  renderAssigneeBadge(null);
  renderAssigneeDropdown();
  renderTagChips([]);
  document.getElementById("priority-dropdown")?.classList.add("hidden");
  document.getElementById("assignee-dropdown")?.classList.add("hidden");
  renderCsatBadge(null, null);
}

async function loadTicketProperties(sessionId) {
  const result = await authedFetch(`/agent/conversations/${sessionId}`);
  if (!result || activeSessionId !== sessionId) return; // conversation switched again before this resolved
  currentTicketProperties = {
    priority: result.priority || "normal",
    tags: result.tags || [],
    assigned_agent: result.assigned_agent || null,
  };
  renderPriorityBadge(currentTicketProperties.priority);
  renderAssigneeDropdown();
  renderAssigneeBadge(currentTicketProperties.assigned_agent);
  renderTagChips(currentTicketProperties.tags);
  renderCsatBadge(result.csat_rating, result.csat_comment);
  
  const mergeContainer = document.getElementById('merge-banner-container');
  if (mergeContainer) {
      if (result.merged_into_session_id) {
          mergeContainer.style.display = 'block';
          mergeContainer.innerHTML = `
              <div style="display:flex; align-items:center; gap:8px;">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
                  <span>This ticket has been merged into <a href="#" onclick="window.loadConversation('${result.merged_into_session_id}'); return false;" style="color:var(--accent-main); font-weight:500;">Ticket ${result.merged_into_short_id || result.merged_into_session_id.substring(0,8)}</a></span>
              </div>
          `;
      } else if (result.merged_from && result.merged_from.length > 0) {
          mergeContainer.style.display = 'block';
          const links = result.merged_from.map(m => `<a href="#" onclick="window.loadConversation('${m.session_id}'); return false;" style="color:var(--accent-main); font-weight:500;">Ticket ${m.short_id || m.session_id.substring(0,8)}</a>`).join(', ');
          mergeContainer.innerHTML = `
              <div style="display:flex; align-items:center; gap:8px;">
                  <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 18l-6-6 6-6"/></svg>
                  <span>${result.merged_from.length} ticket(s) merged into this one: ${links}</span>
              </div>
          `;
      } else {
          mergeContainer.style.display = 'none';
          mergeContainer.innerHTML = '';
      }
  }
}

function renderCsatBadge(rating, comment) {
  const badge = document.getElementById("csat-badge");
  if (!badge) return;
  if (!rating) {
    badge.classList.add("hidden");
    badge.textContent = "";
    badge.removeAttribute("title");
    return;
  }
  badge.classList.remove("hidden");
  badge.textContent = "★".repeat(rating) + "☆".repeat(5 - rating);
  badge.title = comment ? `CSAT: ${rating}/5 — "${comment}"` : `CSAT: ${rating}/5`;
}

async function saveTicketProperty(fields) {
  if (!activeSessionId) return;
  const result = await authedFetch(`/agent/conversations/${activeSessionId}/properties`, "PATCH", fields);
  if (!result) return;
  currentTicketProperties = {
    priority: result.priority || "normal",
    tags: result.tags || [],
    assigned_agent: result.assigned_agent || null,
  };
  renderPriorityBadge(currentTicketProperties.priority);
  renderAssigneeDropdown();
  renderAssigneeBadge(currentTicketProperties.assigned_agent);
  renderTagChips(currentTicketProperties.tags);
  loadConversations(); // list rows show priority/tags too, keep them in sync
}

(function setupTicketPropertiesBar() {
  const priorityBadge = document.getElementById("priority-badge");
  const priorityDropdown = document.getElementById("priority-dropdown");
  const assigneeBadge = document.getElementById("assignee-badge");
  const assigneeDropdown = document.getElementById("assignee-dropdown");
  const addTagBtn = document.getElementById("add-tag-btn");
  const tagInput = document.getElementById("tag-input");
  const tagChips = document.getElementById("tag-chips");
  if (!priorityBadge || !assigneeBadge) return; // markup not present on this page

  function closeAllDropdowns(except) {
    if (priorityDropdown && priorityDropdown !== except) priorityDropdown.classList.add("hidden");
    if (assigneeDropdown && assigneeDropdown !== except) assigneeDropdown.classList.add("hidden");
  }

  priorityBadge.addEventListener("click", (e) => {
    e.stopPropagation();
    const willOpen = priorityDropdown.classList.contains("hidden");
    closeAllDropdowns();
    priorityDropdown.classList.toggle("hidden", !willOpen);
  });

  priorityDropdown.addEventListener("click", (e) => {
    const item = e.target.closest("[data-priority]");
    if (!item) return;
    priorityDropdown.classList.add("hidden");
    if (item.dataset.priority === currentTicketProperties.priority) return;
    saveTicketProperty({ priority: item.dataset.priority });
  });

  assigneeBadge.addEventListener("click", (e) => {
    e.stopPropagation();
    const willOpen = assigneeDropdown.classList.contains("hidden");
    closeAllDropdowns();
    assigneeDropdown.classList.toggle("hidden", !willOpen);
  });

  assigneeDropdown.addEventListener("click", (e) => {
    const item = e.target.closest("[data-assignee]");
    if (!item) return;
    assigneeDropdown.classList.add("hidden");
    const chosen = item.dataset.assignee || null;
    if (chosen === currentTicketProperties.assigned_agent) return;
    saveTicketProperty({ assigned_agent: chosen === null ? "" : chosen });
  });

  document.addEventListener("click", () => closeAllDropdowns());

  addTagBtn.addEventListener("click", () => {
    addTagBtn.classList.add("hidden");
    tagInput.classList.remove("hidden");
    tagInput.value = "";
    tagInput.focus();
  });

  function commitTagInput() {
    const value = tagInput.value.trim();
    tagInput.classList.add("hidden");
    addTagBtn.classList.remove("hidden");
    if (!value) return;
    if (currentTicketProperties.tags.includes(value)) return;
    saveTicketProperty({ tags: [...currentTicketProperties.tags, value] });
  }

  tagInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") { e.preventDefault(); commitTagInput(); }
    if (e.key === "Escape") { tagInput.classList.add("hidden"); addTagBtn.classList.remove("hidden"); }
  });
  tagInput.addEventListener("blur", commitTagInput);

  tagChips.addEventListener("click", (e) => {
    const removeBtn = e.target.closest(".tp-tag-chip__remove");
    if (!removeBtn) return;
    const tagToRemove = removeBtn.dataset.tag;
    saveTicketProperty({ tags: currentTicketProperties.tags.filter(t => t !== tagToRemove) });
  });
})();

// Periodic SLA Check
setInterval(loadConversations, 30000);

// Mobile Sidebar Toggle
document.addEventListener("DOMContentLoaded", () => {
  const mobileToggle = document.getElementById("mobile-sidebar-toggle");
  const sidebar = document.getElementById("sidebar");
  if (mobileToggle && sidebar) {
    function updateSidebarToggleIcon() {
      let isOpen = false;
      if (window.innerWidth <= 1200) {
        isOpen = sidebar.classList.contains("sidebar-open");
      } else {
        isOpen = !sidebar.classList.contains("sidebar-hidden");
      }
      
      if (isOpen) {
        mobileToggle.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="22" height="22"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect><path d="M9 3v18"></path><path d="m16 15-3-3 3-3"></path></svg>';
        mobileToggle.setAttribute("title", "Close Sidebar");
        mobileToggle.setAttribute("aria-label", "Close Sidebar");
        mobileToggle.setAttribute("aria-expanded", "true");
        mobileToggle.classList.add("sidebar-is-open");
      } else {
        mobileToggle.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" width="22" height="22"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"></rect><path d="M9 3v18"></path><path d="m14 9 3 3-3 3"></path></svg>';
        mobileToggle.setAttribute("title", "Open Sidebar");
        mobileToggle.setAttribute("aria-label", "Open Sidebar");
        mobileToggle.setAttribute("aria-expanded", "false");
        mobileToggle.classList.remove("sidebar-is-open");
      }
    }

    mobileToggle.addEventListener("click", () => {
      if (window.innerWidth <= 1200) {
        sidebar.classList.toggle("sidebar-open");
      } else {
        sidebar.classList.toggle("sidebar-hidden");
      }
      updateSidebarToggleIcon();
    });
    
    // Auto-close sidebar on mobile when a conversation is selected
    const originalOpenConv = openConversation;
    window.openConversation = async function(...args) {
      if (window.innerWidth <= 1200) {
        sidebar.classList.remove("sidebar-open");
        updateSidebarToggleIcon();
      }
      return originalOpenConv.apply(this, args);
    };

    updateSidebarToggleIcon();
    window.addEventListener("resize", updateSidebarToggleIcon);
  }
});


document.addEventListener("contextmenu", (e) => {
  const msgWrapper = e.target.closest(".msg-wrapper");
  if (msgWrapper) {
    const dropdownBtn = msgWrapper.querySelector(".msg-dropdown-btn");
    if (dropdownBtn) {
      e.preventDefault();
      dropdownBtn.click();
    }
  }
});





// --- Filters and Saved Views ---
const savedViews = [];

async function loadSavedViews() {
    try {
        const res = await fetch(`${API_BASE}/agent/saved-views`, {
            headers: { 'X-Wrennon-Client': 'agent-dashboard' },
            credentials: 'include'
        });
        if (res.ok) {
            const data = await res.json();
            savedViews.length = 0;
            savedViews.push(...data);
            renderSavedViews();
        }
    } catch (e) {
        console.error("Failed to load saved views", e);
    }
}

function renderSavedViews() {
  const container = document.getElementById("saved-views-container");
  if (!container) return;
  container.innerHTML = "";
  if (savedViews.length > 0) {
     container.style.display = "flex";
     savedViews.forEach((view, idx) => {
        const btn = document.createElement("button");
        btn.className = "badge";
        btn.style.cursor = "pointer";
        btn.style.background = "var(--bg-hover)";
        btn.style.border = "1px solid var(--border-light)";
        btn.style.color = "var(--ink)";
        btn.textContent = view.name;
        
        let filterObj = {};
        try { filterObj = JSON.parse(view.filter_json); } catch(e){}

        btn.onclick = () => {
           document.getElementById("filter-priority").value = filterObj.priority || "";
           document.getElementById("filter-assignee").value = filterObj.assignee || "";
           document.getElementById("filter-tag").value = filterObj.tag || "";
           loadConversations();
           document.getElementById("clear-filters-btn").style.display = "inline-block";
           const badge = document.getElementById("filter-active-badge");
           if (badge) badge.style.display = "block";
        };
        const delBtn = document.createElement("span");
        delBtn.innerHTML = "&times;";
        delBtn.style.marginLeft = "4px";
        delBtn.style.fontWeight = "bold";
        delBtn.onclick = async (e) => {
           e.stopPropagation();
           try {
               await fetch(`${API_BASE}/agent/saved-views/${view.id}`, {
                   method: 'DELETE',
                   headers: { 'X-Wrennon-Client': 'agent-dashboard' },
                   credentials: 'include'
               });
               loadSavedViews();
           } catch(err) { console.error(err); }
        };
        btn.appendChild(delBtn);
        container.appendChild(btn);
     });
  } else {
     container.style.display = "none";
  }
}

document.getElementById("save-view-btn")?.addEventListener("click", async () => {
  const pri = document.getElementById("filter-priority").value;
  const ass = document.getElementById("filter-assignee").value;
  const tag = document.getElementById("filter-tag").value;
  if (!pri && !ass && !tag) return alert("Nothing to save");
  const name = prompt("Name for this view?");
  if (name) {
    const filterJson = JSON.stringify({ priority: pri, assignee: ass, tag: tag });
    try {
        await fetch(`${API_BASE}/agent/saved-views`, {
            method: 'POST',
            headers: { 
                'X-Wrennon-Client': 'agent-dashboard',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ name: name, filter_json: filterJson }),
            credentials: 'include'
        });
        loadSavedViews();
    } catch(err) { console.error(err); }
  }
});

const globalFilterBtn = document.getElementById("global-filter-btn");
const globalFilterDropdown = document.getElementById("global-filter-dropdown");
if (globalFilterBtn && globalFilterDropdown) {
  globalFilterBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    globalFilterDropdown.classList.toggle("hidden");
  });
  document.addEventListener("click", (e) => {
    if (!globalFilterDropdown.contains(e.target) && !globalFilterBtn.contains(e.target)) {
      globalFilterDropdown.classList.add("hidden");
    }
  });
}

const menuBulkSelectBtn = document.getElementById("menu-bulk-select-btn");
if (menuBulkSelectBtn) {
  menuBulkSelectBtn.addEventListener("click", () => {
    const sidebar = document.getElementById("sidebar");
    sidebar.classList.add("bulk-mode-active");
    const themeDropdown = document.getElementById("theme-dropdown");
    if (themeDropdown) {
      themeDropdown.classList.add("hidden");
    }
  });
}

document.getElementById("apply-filters-btn")?.addEventListener("click", () => {
  const pri = document.getElementById("filter-priority").value;
  const ass = document.getElementById("filter-assignee").value;
  const tag = document.getElementById("filter-tag").value;
  const hasFilters = pri || ass || tag;
  document.getElementById("clear-filters-btn").style.display = hasFilters ? "inline-block" : "none";
  const badge = document.getElementById("filter-active-badge");
  if (badge) badge.style.display = hasFilters ? "block" : "none";
  loadConversations();
});
document.getElementById("clear-filters-btn")?.addEventListener("click", () => {
  document.getElementById("filter-priority").value = "";
  document.getElementById("filter-assignee").value = "";
  document.getElementById("filter-tag").value = "";
  document.getElementById("clear-filters-btn").style.display = "none";
  const badge = document.getElementById("filter-active-badge");
  if (badge) badge.style.display = "none";
  loadConversations();
});
loadSavedViews();

// --- Bulk Actions ---
const selectedConversations = new Set();
function toggleBulkSelection(cb, sessionId) {
    if (cb.checked) {
        selectedConversations.add(sessionId);
        document.getElementById("sidebar").classList.add("bulk-mode-active");
    } else {
        selectedConversations.delete(sessionId);
        if (selectedConversations.size === 0) {
            document.getElementById("sidebar").classList.remove("bulk-mode-active");
        }
    }
    updateBulkActionBar();
}

function updateBulkActionBar() {
    const selectAllCheckbox = document.getElementById("bulk-select-all-checkbox");
    const countSpan = document.getElementById("bulk-selected-count");
    if (countSpan) countSpan.textContent = selectedConversations.size;
    
    if (selectAllCheckbox) {
        const visibleCheckboxes = document.querySelectorAll(".conv-checkbox");
        const allChecked = visibleCheckboxes.length > 0 && Array.from(visibleCheckboxes).every(cb => cb.checked);
        selectAllCheckbox.checked = allChecked;
    }

    if (selectedConversations.size === 0) {
        document.getElementById("bulk-action-value-container").style.display = "none";
        document.getElementById("bulk-action-select").value = "";
    }
}

document.getElementById("bulk-cancel-btn")?.addEventListener("click", () => {
    selectedConversations.clear();
    document.querySelectorAll(".conv-checkbox").forEach(cb => cb.checked = false);
    document.getElementById("sidebar").classList.remove("bulk-mode-active");
    updateBulkActionBar();
});

document.getElementById("bulk-select-header-cancel")?.addEventListener("click", () => {
    selectedConversations.clear();
    document.querySelectorAll(".conv-checkbox").forEach(cb => cb.checked = false);
    document.getElementById("sidebar").classList.remove("bulk-mode-active");
    updateBulkActionBar();
});

document.getElementById("bulk-select-all-checkbox")?.addEventListener("change", (e) => {
    const isChecked = e.target.checked;
    document.querySelectorAll(".conv-checkbox").forEach(cb => {
        cb.checked = isChecked;
        const sessionId = cb.getAttribute("data-session-id");
        if (isChecked) {
            selectedConversations.add(sessionId);
        } else {
            selectedConversations.delete(sessionId);
        }
    });
    if (selectedConversations.size === 0 && !isChecked) {
        document.getElementById("sidebar").classList.remove("bulk-mode-active");
    } else {
        document.getElementById("sidebar").classList.add("bulk-mode-active");
    }
    updateBulkActionBar();
});

document.getElementById("bulk-action-select")?.addEventListener("change", (e) => {
    const val = e.target.value;
    const valContainer = document.getElementById("bulk-action-value-container");
    const valSelect = document.getElementById("bulk-action-value-select");
    if (val === "assign") {
        valContainer.style.display = "block";
        valSelect.innerHTML = `<option value="">Unassigned</option>`;
        const agents = document.getElementById("filter-assignee").innerHTML;
        valSelect.innerHTML = agents;
    } else if (val === "priority") {
        valContainer.style.display = "block";
        valSelect.innerHTML = `
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="normal">Normal</option>
            <option value="low">Low</option>
        `;
    } else {
        valContainer.style.display = "none";
    }
});

document.getElementById("bulk-apply-btn")?.addEventListener("click", async () => {
    const action = document.getElementById("bulk-action-select").value;
    if (!action) return;
    const val = document.getElementById("bulk-action-value-select").value;
    
    const session_ids = Array.from(selectedConversations);
    try {
        const response = await fetch(`${API_BASE}/agent/conversations/bulk`, {
            method: "PATCH",
            credentials: "include",
            headers: { 
                "Content-Type": "application/json",
                "X-Wrennon-Client": "agent-dashboard"
            },
            body: JSON.stringify({ session_ids, action: action, value: val })
        });
        if (response.ok) {
            selectedConversations.clear();
            document.querySelectorAll(".conv-checkbox").forEach(cb => cb.checked = false);
            updateBulkActionBar();
            loadConversations();
            if (activeSessionId && session_ids.includes(activeSessionId)) {
                // refresh current open conversation if it was selected
                fetchAndRenderMessages(activeSessionId);
            }
        } else {
            const err = await response.json();
            alert("Bulk action failed: " + (err.detail || ""));
        }
    } catch (e) {
        console.error("Bulk apply fetch error:", e);
        alert("Network error: " + e.message);
    }
});

// populate filter-assignee when agents are loaded
const originalLoadAgents = loadAgents;
loadAgents = async function() {
    await originalLoadAgents();
    const filterAss = document.getElementById("filter-assignee");
    if (filterAss) {
        filterAss.innerHTML = `<option value="">Assignee: All</option><option value="unassigned">Unassigned</option>`;
        Object.keys(AGENT_DIRECTORY).forEach(uname => {
            const opt = document.createElement("option");
            opt.value = uname;
            opt.textContent = AGENT_DIRECTORY[uname].full_name;
            filterAss.appendChild(opt);
        });
    }
}

// --- View Switching Logic ---
document.addEventListener('DOMContentLoaded', () => {
  const views = {
    'dashboard': document.getElementById('view-dashboard'),
    'conversations': document.getElementById('view-conversations'),
    'customers': document.getElementById('view-customers'),
    'analytics': document.getElementById('view-analytics')
  };
  const btns = {
    'dashboard': document.getElementById('nav-dashboard-btn'),
    'conversations': document.getElementById('nav-conversations-btn'),
    'customers': document.getElementById('nav-customers-btn'),
    'analytics': document.getElementById('nav-analytics-btn')
  };

  function switchView(viewName) {
    window.currentView = viewName;
    // Hide all views and remove active class from all buttons
    Object.keys(views).forEach(key => {
      if(views[key]) views[key].classList.add('hidden');
      if(btns[key]) btns[key].classList.remove('active');
    });

    // Show selected view and set button to active
    if(views[viewName]) {
      views[viewName].classList.remove('hidden');
    }
    if(btns[viewName]) {
      btns[viewName].classList.add('active');
    }
    
    if (viewName === 'dashboard') {
        window.loadDashboard();
    } else if (viewName === 'customers') {
        window.loadCustomers();
    } else if (viewName === 'analytics') {
        window.loadAnalytics();
    }
  }

  window.loadDashboard = async function() {
      try {
          const res = await fetch(`${API_BASE}/agent/dashboard-summary`, {
              headers: { 'X-Wrennon-Client': 'agent-dashboard' },
              credentials: 'include'
          });
          if (res.ok) {
              const data = await res.json();
              const openEl = document.getElementById('metric-open-tickets');
              if(openEl) openEl.textContent = data.open_tickets;
              const unassignedEl = document.getElementById('metric-unassigned');
              if(unassignedEl) unassignedEl.textContent = data.unassigned;
              const solvedEl = document.getElementById('metric-solved-today');
              if(solvedEl) solvedEl.textContent = data.solved_today;
              const csatEl = document.getElementById('metric-csat');
              if (csatEl) {
                  csatEl.textContent = data.csat_score ? data.csat_score.toFixed(1) + ' ★' : '—';
              }
              const slaList = document.getElementById('sla-risk-list');
              if (slaList && data.sla_risks) {
                  slaList.innerHTML = '';
                  if (data.sla_risks.length === 0) {
                      slaList.innerHTML = '<div style="padding: 16px; color: var(--text-muted); text-align: center;">No SLA risks detected. Inbox is clear!</div>';
                  } else {
                      data.sla_risks.forEach(risk => {
                          let badgeHtml = '';
                          let iconClass = 'warning';
                          if (risk.sla_status === 'breached') {
                              badgeHtml = `<span class="badge" style="background: var(--danger); color:white;">Breached SLA</span>`;
                              iconClass = 'danger';
                          } else if (risk.sla_status === 'warning') {
                              badgeHtml = `<span class="badge" style="background: var(--warning); color:white;">SLA Warning</span>`;
                              iconClass = 'warning';
                          } else {
                              badgeHtml = `<span class="badge" style="background: var(--success); color:white;">SLA OK</span>`;
                              iconClass = 'success';
                          }
                          const ticketId = risk.short_id ? `#${risk.short_id.substring(0,8).toUpperCase()}` : '';
                          const div = document.createElement('div');
                          div.className = `activity-item ${iconClass}`;
                          div.style.cursor = 'pointer';
                          div.innerHTML = `
                              <div class="activity-icon" style="background: var(--${iconClass}); color: white;">!</div>
                              <div class="activity-details" style="flex: 1;">
                                  <p style="display:flex; justify-content: space-between;"><strong>Unresolved Ticket</strong> ${badgeHtml}</p>
                                  <span class="time">${ticketId} - ${escapeHtml(risk.customer_email || 'Unknown Customer')}</span>
                              </div>
                          `;
                          div.onclick = () => {
                              switchView('conversations');
                              openConversation(risk.session_id, risk.customer_email, risk.short_id, false, risk.created_at);
                          };
                          slaList.appendChild(div);
                      });
                  }
              }
              if (window.miniVolumeChart && data.hourly_volume) {
                  window.miniVolumeChart.data.datasets[0].data = data.hourly_volume;
                  window.miniVolumeChart.data.labels = data.hourly_volume.map((_, i) => `${i}:00`);
                  window.miniVolumeChart.update();
              }
              
              const workloadList = document.getElementById('agent-chat-counts-list');
              if (workloadList && data.agent_chat_counts) {
                  workloadList.innerHTML = '';
                  for (const [agentName, count] of Object.entries(data.agent_chat_counts)) {
                      const div = document.createElement('div');
                      div.style.display = 'flex';
                      div.style.justifyContent = 'space-between';
                      div.style.padding = '8px 0';
                      div.style.borderBottom = '1px solid var(--line)';
                      div.style.fontSize = '14px';
                      div.innerHTML = `
                          <span>${agentName}</span>
                          <span style="font-weight: 600; color: var(--accent);">${count} active</span>
                      `;
                      workloadList.appendChild(div);
                  }
              }
          }
      } catch (e) { console.error("Failed to load dashboard summary", e); }
  };

  window.loadAnalytics = async function() {
      try {
          const rangeSelect = document.getElementById('analytics-date-range');
          const rangeVal = rangeSelect ? rangeSelect.value : 'all';
          const res = await fetch(`${API_BASE}/analytics/dashboard-metrics?range=${rangeVal}`, {
              headers: { 'X-Wrennon-Client': 'agent-dashboard' },
              credentials: 'include'
          });
          if (res.ok) {
              const data = await res.json();
              const formatDuration = (secs) => {
                  if (!secs) return "—";
                  const h = Math.floor(secs / 3600);
                  const m = Math.floor((secs % 3600) / 60);
                  if (h > 0) return `${h}h ${m}m`;
                  return `${m}m`;
              };
              const frtEl = document.getElementById('analytics-first-response');
              if(frtEl) frtEl.textContent = formatDuration(data.first_response_time_seconds);
              const artEl = document.getElementById('analytics-avg-resolution-time');
              if(artEl) artEl.textContent = formatDuration(data.avg_resolution_time_seconds);
              const otEl = document.getElementById('analytics-one-touch');
              if(otEl) otEl.textContent = data.one_touch_resolutions_pct ? data.one_touch_resolutions_pct.toFixed(0) + '%' : '0%';
              
              if (window.volumeChart) {
                  window.volumeChart.data.datasets[0].data = data.hourly_volume;
                  window.volumeChart.data.labels = data.volume_labels;
                  window.volumeChart.update();
              }
              
              // Rolling CSAT
              const rcEl = document.getElementById('analytics-rolling-csat');
              if (rcEl) {
                  rcEl.textContent = data.rolling_weekly_csat ? data.rolling_weekly_csat.toFixed(1) + ' / 5.0' : '—';
              }
              
              // Agent Leaderboard
              const lbBody = document.getElementById('analytics-leaderboard-body');
              if (lbBody && data.agent_leaderboard) {
                  lbBody.innerHTML = '';
                  data.agent_leaderboard.forEach(ag => {
                      const tr = document.createElement('tr');
                      tr.style.borderBottom = '1px solid var(--line)';
                      tr.innerHTML = `
                          <td style="padding: 8px;">${ag.assigned_agent || 'Unassigned'}</td>
                          <td style="padding: 8px;">${ag.resolved_count}</td>
                          <td style="padding: 8px;">${formatDuration(ag.avg_resolution_time_seconds)}</td>
                      `;
                      lbBody.appendChild(tr);
                  });
              }
              
              // Tags Frequency
              if (window.tagsChart && data.tag_frequency) {
                  const sortedTags = data.tag_frequency.slice(0, 5); // top 5
                  window.tagsChart.data.labels = sortedTags.map(t => t.tag);
                  window.tagsChart.data.datasets[0].data = sortedTags.map(t => t.count);
                  window.tagsChart.update();
              }
              if (window.csatChart) {
                  const counts = data.csat_distribution || [0,0,0,0,0];
                  // backend is [1, 2, 3, 4, 5], frontend is ['5 Stars', '4 Stars', '3 Stars', '1-2 Stars']
                  const mappedCounts = [
                      counts[4],                 // 5 stars
                      counts[3],                 // 4 stars
                      counts[2],                 // 3 stars
                      counts[0] + counts[1]      // 1-2 stars
                  ];
                  window.csatChart.data.datasets[0].data = mappedCounts;
                  window.csatChart.update();
              }
          }
      } catch (e) { console.error("Failed to load analytics", e); }
      
      // Fetch additional sections
      window.fetchSystemAnalytics();
      window.fetchScorecards();
  };
  
  window.fetchSystemAnalytics = async function() {
      try {
          const res = await fetch(`${API_BASE}/analytics/stats`, {
              headers: { 'X-Wrennon-Client': 'agent-dashboard' },
              credentials: 'include'
          });
          if (!res.ok) return;
          const data = await res.json();
          const tTickets = document.getElementById('analytics-total-tickets');
          if (tTickets) tTickets.innerText = data.total_tickets;
          const defRate = document.getElementById('analytics-deflection-rate');
          if (defRate) defRate.innerText = data.deflection_rate + "%";
          const aiRes = document.getElementById('analytics-ai-resolved');
          if (aiRes) aiRes.innerText = `(${data.resolved_by_ai} resolved by AI)`;
          const rev = document.getElementById('analytics-revenue');
          if (rev) rev.innerText = `$${data.revenue_generated.toFixed(2)}`;
          const upsells = document.getElementById('analytics-upsells');
          if (upsells) upsells.innerText = data.upsell_count;
      } catch (err) {
          console.error("Failed to fetch system analytics:", err);
      }
  };
  
  window.fetchScorecards = async function() {
      try {
          const res = await fetch(`${API_BASE}/agent/my-scorecards`, {
              headers: { 'X-Wrennon-Client': 'agent-dashboard' },
              credentials: 'include'
          });
          if (res.ok) {
              const data = await res.json();
              const tbody = document.getElementById('qa-scorecards-list');
              if (!tbody) return;
              if (data.length === 0) {
                  tbody.innerHTML = '<tr><td colspan="7" style="text-align: center; padding: 20px; color: var(--ink-soft);">No scorecards yet. Resolve a conversation to generate one.</td></tr>';
                  return;
              }
              tbody.innerHTML = '';
              data.forEach(card => {
                  const date = new Date(card.created_at).toLocaleString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                  tbody.innerHTML += `
                      <tr>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line);">${date}</td>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line); font-family: 'JetBrains Mono', monospace; font-size: 13px;">${card.short_id || card.conversation_id.substring(0, 8)}...</td>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line); text-align: center;">${card.empathy_score}/10</td>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line); text-align: center;">${card.accuracy_score}/10</td>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line); text-align: center;">${card.resolution_score}/10</td>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line); text-align: center; color: var(--accent); font-weight: 600;">${card.csat_prediction}/5</td>
                          <td style="padding: 12px; border-bottom: 1px solid var(--line);">
                              <textarea readonly style="width: 100%; height: 60px; padding: 8px; border-radius: 4px; border: 1px solid var(--border-light); background: transparent; color: inherit; font-family: 'Inter', sans-serif; resize: vertical; font-size: 13px;">${card.feedback_notes}</textarea>
                          </td>
                      </tr>
                  `;
              });
          }
      } catch (err) {
          console.error("Failed to fetch scorecards:", err);
      }
  };

  if(btns['dashboard']) btns['dashboard'].addEventListener('click', () => { window.location.hash = 'dashboard'; switchView('dashboard'); });
  if(btns['conversations']) btns['conversations'].addEventListener('click', () => { window.location.hash = 'conversations'; switchView('conversations'); });
  if(btns['customers']) btns['customers'].addEventListener('click', () => { window.location.hash = 'customers'; switchView('customers'); });
  if(btns['analytics']) btns['analytics'].addEventListener('click', () => { window.location.hash = 'analytics'; switchView('analytics'); });

  // Check hash on load
  if (window.location.hash) {
      const hash = window.location.hash.substring(1);
      if (['dashboard', 'conversations', 'customers', 'analytics'].includes(hash)) {
          switchView(hash);
      } else {
          switchView('conversations');
      }
  } else {
      switchView('conversations');
  }
});


// --- Production Features Logic ---
document.addEventListener('DOMContentLoaded', () => {
    // 1. Chart.js Initialization
    let volumeChart, csatChart, resolutionChart, miniVolumeChart;

    function initCharts() {
        const textColor = getComputedStyle(document.documentElement).getPropertyValue('--ink').trim() || '#1e293b';
        const gridColor = getComputedStyle(document.documentElement).getPropertyValue('--line').trim() || '#e2e8f0';
        const accentColor = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#3b82f6';
        
        Chart.defaults.color = textColor;
        Chart.defaults.font.family = "'Inter', sans-serif";

        const commonOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: { grid: { color: gridColor } },
                y: { grid: { color: gridColor }, beginAtZero: true }
            }
        };

        // Mini Volume Chart (Dashboard)
        const ctxMini = document.getElementById('miniVolumeChart');
        if(ctxMini && !window.miniVolumeChart) {
            let gradientMini;
            if (ctxMini.getContext) {
                const ctx = ctxMini.getContext('2d');
                gradientMini = ctx.createLinearGradient(0, 0, 0, 150);
                gradientMini.addColorStop(0, accentColor + '40');
                gradientMini.addColorStop(1, accentColor + '00');
            }
            window.miniVolumeChart = new Chart(ctxMini, {
                type: 'line',
                data: {
                    labels: ['8am', '10am', '12pm', '2pm', '4pm', '6pm'],
                    datasets: [{
                        data: [12, 28, 45, 32, 56, 18],
                        borderColor: accentColor,
                        backgroundColor: gradientMini || 'transparent',
                        borderWidth: 2,
                        tension: 0.4,
                        fill: true,
                        pointRadius: 0
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    plugins: { legend: { display: false }, tooltip: { enabled: false } },
                    scales: { x: { display: false }, y: { display: false } }
                }
            });
        }

        // Volume Chart (Analytics)
        const ctxVol = document.getElementById('volumeChart');
        if(ctxVol && !window.volumeChart) {
            let gradientVol;
            if (ctxVol.getContext) {
                const ctx = ctxVol.getContext('2d');
                gradientVol = ctx.createLinearGradient(0, 0, 0, 300);
                gradientVol.addColorStop(0, accentColor + '60');
                gradientVol.addColorStop(1, accentColor + '00');
            }
            window.volumeChart = new Chart(ctxVol, {
                type: 'line',
                data: {
                    labels: Array.from({length: 24}, (_, i) => `${i}:00`),
                    datasets: [{
                        label: 'Tickets',
                        data: Array(24).fill(0),
                        borderColor: accentColor,
                        backgroundColor: gradientVol || (accentColor + '20'),
                        borderWidth: 3,
                        fill: true,
                        tension: 0.4,
                        pointBackgroundColor: '#ffffff',
                        pointBorderColor: accentColor,
                        pointBorderWidth: 2,
                        pointRadius: 3,
                        pointHoverRadius: 5
                    }]
                },
                options: commonOptions
            });
        }

        // CSAT Chart (Analytics)
        const ctxCsat = document.getElementById('csatChart');
        if(ctxCsat && !window.csatChart) {
            window.csatChart = new Chart(ctxCsat, {
                type: 'doughnut',
                data: {
                    labels: ['5 Stars', '4 Stars', '3 Stars', '1-2 Stars'],
                    datasets: [{
                        data: [0, 0, 0, 0],
                        backgroundColor: ['#22c55e', '#84cc16', '#eab308', '#ef4444'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true, maintainAspectRatio: false,
                    cutout: '70%',
                    plugins: {
                        legend: { position: 'right' }
                    }
                }
            });
        }

        // Tags Chart (Analytics)
        const ctxTags = document.getElementById('tagsChart');
        if(ctxTags && !window.tagsChart) {
            window.tagsChart = new Chart(ctxTags, {
                type: 'bar',
                data: {
                    labels: [],
                    datasets: [{
                        label: 'Count',
                        data: [],
                        backgroundColor: accentColor,
                        borderRadius: 4
                    }]
                },
                options: { ...commonOptions, indexAxis: 'y' }
            });
        }
    }

    // Expose a method to rebuild charts when theme changes
    window.refreshCharts = function() {
        if (window.miniVolumeChart) { window.miniVolumeChart.destroy(); window.miniVolumeChart = null; }
        if (window.volumeChart) { window.volumeChart.destroy(); window.volumeChart = null; }
        if (window.csatChart) { window.csatChart.destroy(); window.csatChart = null; }
        if (window.tagsChart) { window.tagsChart.destroy(); window.tagsChart = null; }
        initCharts();
    };

    // Call initCharts when Analytics view is shown, or just initialize immediately if Chart.js is loaded
    if(typeof Chart !== 'undefined') {
        initCharts();
    } else {
        // Fallback if CDN is slow
        setTimeout(initCharts, 1000);
    }


    // 2. Customers Table Logic (API & Rendering)
    window.customersData = [];
    
    window.loadCustomers = async function() {
        try {
            const res = await fetch(`${API_BASE}/agent/customers`, {
                headers: { 'X-Wrennon-Client': 'agent-dashboard' },
                credentials: 'include'
            });
            if (res.ok) {
                window.customersData = await res.json();
                renderCustomers();
            }
        } catch (e) {
            console.error('Failed to load customers', e);
        }
    };

    let currentSort = { column: 'total_tickets', dir: 'desc' };

    function renderCustomers() {
        const tbody = document.getElementById('customers-table-body');
        if(!tbody) return;
        
        // Filter
        const searchInput = document.getElementById('customer-search-input');
        const query = searchInput ? searchInput.value.toLowerCase() : '';
        let filtered = window.customersData;
        if (query) {
            filtered = filtered.filter(c => c.email && c.email.toLowerCase().includes(query));
        }
        
        // Sort
        const sorted = [...filtered].sort((a, b) => {
            let valA = a[currentSort.column];
            let valB = b[currentSort.column];
            
            // Handle nulls
            if (valA === null) valA = '';
            if (valB === null) valB = '';

            if (valA < valB) return currentSort.dir === 'asc' ? -1 : 1;
            if (valA > valB) return currentSort.dir === 'asc' ? 1 : -1;
            return 0;
        });

        // Generate initials/color
        function stringToColor(str) {
            let hash = 0;
            for (let i = 0; i < str.length; i++) hash = str.charCodeAt(i) + ((hash << 5) - hash);
            let color = '#';
            for (let i = 0; i < 3; i++) color += ('00' + ((hash >> (i * 8)) & 0xFF).toString(16)).substr(-2);
            return color;
        }

        // Format dates
        function formatAgo(isoStr) {
            if (!isoStr) return "—";
            const diff = (new Date() - new Date(isoStr)) / 1000;
            if (diff < 60) return "Just now";
            const mins = Math.floor(diff / 60);
            if (mins < 60) return `${mins}m ago`;
            const hrs = Math.floor(mins / 60);
            if (hrs < 24) return `${hrs}h ago`;
            const days = Math.floor(hrs / 24);
            return `${days}d ago`;
        }

        tbody.innerHTML = sorted.map(c => {
            const avatarUrl = c.email ? `https://i.pravatar.cc/150?u=${encodeURIComponent(c.email)}` : '/agent/images/default-avatar.png?v=2';
            const resRatio = c.resolved_ratio != null ? (c.resolved_ratio * 100).toFixed(0) + '%' : '—';
            const avgCsat = c.avg_csat != null ? c.avg_csat.toFixed(1) + ' ★' : '—';
            const lastActive = formatAgo(c.last_active);
            
            return `
            <tr>
                <td>
                    <div class="customer-cell">
                    <img src="${avatarUrl}" class="avatar" style="width: 32px; height: 32px; border-radius: 50%; object-fit: cover; border: 1px solid var(--border-light);" alt="Avatar" onerror="this.src='/agent/images/default-avatar.png?v=2'">
                    <div>
                        <div class="name">${escapeHtml(c.email || 'Unknown')}</div>
                        <div class="email">${escapeHtml(c.email || 'Unknown')}</div>
                    </div>
                    </div>
                </td>
                <td>${c.total_tickets}</td>
                <td>${resRatio}</td>
                <td>${avgCsat}</td>
                <td>${lastActive}</td>
                <td>
                    <button class="btn-icon" title="More Actions">
                        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="1"></circle><circle cx="12" cy="5" r="1"></circle><circle cx="12" cy="19" r="1"></circle></svg>
                    </button>
                </td>
            </tr>
            `;
        }).join('');

        // Update headers
        document.querySelectorAll('th.sortable').forEach(th => {
            th.classList.remove('sort-asc', 'sort-desc');
            if(th.dataset.sort === currentSort.column) {
                th.classList.add(currentSort.dir === 'asc' ? 'sort-asc' : 'sort-desc');
            }
        });

        const paginationInfo = document.querySelector('.pagination-info');
        if (paginationInfo) {
            paginationInfo.textContent = `Showing ${filtered.length > 0 ? 1 : 0}-${filtered.length} of ${window.customersData.length} customers`;
        }
        
        const prevBtn = document.querySelector('.pagination button:first-child');
        const nextBtn = document.querySelector('.pagination button:last-child');
        if (prevBtn) { prevBtn.disabled = true; prevBtn.style.opacity = '0.5'; }
        if (nextBtn) { nextBtn.disabled = true; nextBtn.style.opacity = '0.5'; }
    }

    document.querySelectorAll('th.sortable').forEach(th => {
        th.addEventListener('click', () => {
            const col = th.dataset.sort;
            if(currentSort.column === col) {
                currentSort.dir = currentSort.dir === 'asc' ? 'desc' : 'asc';
            } else {
                currentSort.column = col;
                currentSort.dir = 'asc';
            }
            renderCustomers();
        });
    });

    const searchInput = document.getElementById('customer-search-input');
    if (searchInput) {
        searchInput.addEventListener('input', () => {
            renderCustomers();
        });
    }

    const exportBtn = document.getElementById('customer-export-btn');
    if (exportBtn) {
        exportBtn.addEventListener('click', () => {
            const query = searchInput ? searchInput.value.toLowerCase() : '';
            let filtered = window.customersData;
            if (query) {
                filtered = filtered.filter(c => c.email && c.email.toLowerCase().includes(query));
            }
            
            let csv = 'Customer,Total Tickets,Resolved Ratio,Avg CSAT,Last Active\n';
            filtered.forEach(c => {
                const resRatio = c.resolved_ratio != null ? (c.resolved_ratio * 100).toFixed(0) + '%' : '';
                const avgCsat = c.avg_csat != null ? c.avg_csat.toFixed(1) : '';
                csv += `"${c.email || ''}",${c.total_tickets},"${resRatio}","${avgCsat}","${c.last_active || ''}"\n`;
            });
            
            const blob = new Blob([csv], { type: 'text/csv' });
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'customers.csv';
            a.click();
            window.URL.revokeObjectURL(url);
        });
    }

    renderCustomers();

    // 4. Update Charts when theme changes
    const observer = new MutationObserver((mutations) => {
        mutations.forEach((mutation) => {
            if (mutation.attributeName === 'data-theme') {
                if(volumeChart) volumeChart.destroy();
                if(csatChart) csatChart.destroy();
                if(resolutionChart) resolutionChart.destroy();
                if(miniVolumeChart) miniVolumeChart.destroy();
                volumeChart = csatChart = resolutionChart = miniVolumeChart = null;
                setTimeout(initCharts, 100);
            }
        });
    });
    observer.observe(document.documentElement, { attributes: true });

});

document.addEventListener('DOMContentLoaded', () => {
  const convOverflowBtn = document.getElementById('conv-overflow-btn');
  const convOverflowMenu = document.getElementById('conv-overflow-menu');
  if (convOverflowBtn && convOverflowMenu) {
      convOverflowBtn.addEventListener('click', (e) => {
          e.stopPropagation();
          convOverflowMenu.classList.toggle('hidden');
      });
      document.addEventListener('click', (e) => {
          if (!convOverflowMenu.contains(e.target) && e.target !== convOverflowBtn) {
              convOverflowMenu.classList.add('hidden');
          }
      });
  }

  const mergeBtn = document.getElementById('merge-ticket-btn');
  if (mergeBtn) {
      mergeBtn.addEventListener('click', () => {
          convOverflowMenu.classList.add('hidden');
          const modal = document.getElementById('merge-modal');
          modal.style.display = 'flex';
      });
  }

  const confirmMergeBtn = document.getElementById('confirm-merge-btn');
  if (confirmMergeBtn) {
      confirmMergeBtn.addEventListener('click', async () => {
          const targetId = document.getElementById('merge-target-input').value.trim();
          if (!targetId) {
              window.showToast("Please enter a target ticket ID", "error");
              return;
          }
          
          let resolvedTargetId = targetId;
          // If they entered a short_id, we should technically find the session_id
          // But our API currently takes target_session_id. 
          // Wait, the agent might enter a short ID since that's what they see. 
          // But since the API requires target_session_id, we might need a backend fix to resolve short_ids.
          // For now, let's just send what they typed.
          
          try {
              const res = await fetch(`${API_BASE}/agent/conversations/${activeSessionId}/merge`, {
                  method: "POST",
                  headers: { "Content-Type": "application/json", 'Authorization': getAuthToken() },
                  body: JSON.stringify({ target_session_id: resolvedTargetId })
              });
              if (!res.ok) {
                  const data = await res.json();
                  throw new Error(data.detail || 'Failed to merge');
              }
              window.showToast("Ticket merged successfully!");
              document.getElementById('merge-modal').style.display = 'none';
              window.loadConversation(activeSessionId); // reload to show banner
          } catch (err) {
              window.showToast(err.message, "error");
          }
      });
  }
});

// ==========================================
// DEVELOPER SETTINGS (API KEYS)
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
    const devSettingsBtn = document.getElementById('dev-settings-btn');
    const devSettingsModal = document.getElementById('dev-settings-modal');
    const devSettingsCloseBtn = document.getElementById('dev-settings-close-btn');
    const apiKeysList = document.getElementById('api-keys-list');
    const createApiKeyBtn = document.getElementById('create-api-key-btn');
    const newApiKeyName = document.getElementById('new-api-key-name');
    const newApiKeyResult = document.getElementById('new-api-key-result');
    const newApiKeyValue = document.getElementById('new-api-key-value');
    const copyApiKeyBtn = document.getElementById('copy-api-key-btn');

    if (!devSettingsBtn || !devSettingsModal) return;

    devSettingsBtn.addEventListener('click', () => {
        // Hide theme dropdown if open
        const themeDropdown = document.getElementById('theme-dropdown');
        if (themeDropdown) themeDropdown.classList.add('hidden');
        
        devSettingsModal.style.display = 'flex';
        loadApiKeys();
        
        // Reset new key result state
        newApiKeyName.value = '';
        newApiKeyResult.style.display = 'none';
    });

    devSettingsCloseBtn.addEventListener('click', () => {
        devSettingsModal.style.display = 'none';
    });

    // Close on click outside
    devSettingsModal.addEventListener('click', (e) => {
        if (e.target === devSettingsModal) {
            devSettingsModal.style.display = 'none';
        }
    });

    async function loadApiKeys() {
        try {
            apiKeysList.innerHTML = '<div style="padding: 12px; text-align: center; color: var(--ink-soft); font-size: 0.9rem;">Loading API keys...</div>';
            
            const response = await fetch(`${API_BASE}/agent/api-keys`, {
                headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
            });
            
            if (!response.ok) {
                if (response.status === 403) {
                    apiKeysList.innerHTML = '<div style="padding: 12px; text-align: center; color: var(--danger); font-size: 0.9rem;">You do not have permission to manage API keys.</div>';
                    return;
                }
                throw new Error('Failed to load API keys');
            }
            
            const keys = await response.json();
            
            if (keys.length === 0) {
                apiKeysList.innerHTML = '<div style="padding: 12px; text-align: center; color: var(--ink-soft); font-size: 0.9rem;">No API keys generated yet.</div>';
                return;
            }
            
            apiKeysList.innerHTML = '';
            keys.forEach(key => {
                const el = document.createElement('div');
                el.style.display = 'flex';
                el.style.justifyContent = 'space-between';
                el.style.alignItems = 'center';
                el.style.padding = '12px';
                el.style.background = 'var(--bg-body)';
                el.style.border = '1px solid var(--line)';
                el.style.borderRadius = '6px';
                
                const createdDate = new Date(key.created_at).toLocaleDateString();
                
                el.innerHTML = `
                    <div>
                        <div style="font-weight: 600; font-size: 0.95rem; color: var(--ink);">${escapeHtml(key.name)}</div>
                        <div style="font-size: 0.8rem; color: var(--ink-soft); margin-top: 4px;">Created: ${createdDate}</div>
                    </div>
                    <button class="revoke-key-btn" data-id="${key.id}" style="background: none; border: 1px solid var(--danger); color: var(--danger); padding: 6px 12px; border-radius: 4px; cursor: pointer; font-size: 0.85rem;">Revoke</button>
                `;
                apiKeysList.appendChild(el);
            });
            
            // Bind revoke buttons
            document.querySelectorAll('.revoke-key-btn').forEach(btn => {
                btn.addEventListener('click', async (e) => {
                    if (!confirm('Are you sure you want to revoke this API key? It will immediately stop working.')) return;
                    
                    const id = e.target.getAttribute('data-id');
                    try {
                        const res = await fetch(`${API_BASE}/agent/api-keys/${id}`, {
                            method: 'DELETE',
                            headers: { 'Authorization': `Bearer ${localStorage.getItem('token')}` }
                        });
                        
                        if (res.ok) {
                            loadApiKeys();
                        } else {
                            alert('Failed to revoke API key');
                        }
                    } catch (err) {
                        console.error('Error revoking API key:', err);
                        alert('Error revoking API key');
                    }
                });
            });
        } catch (err) {
            console.error('Error loading API keys:', err);
            apiKeysList.innerHTML = '<div style="padding: 12px; text-align: center; color: var(--danger); font-size: 0.9rem;">Failed to load API keys.</div>';
        }
    }

    createApiKeyBtn.addEventListener('click', async () => {
        const name = newApiKeyName.value.trim();
        if (!name) {
            alert('Please enter a name for the API key');
            return;
        }
        
        try {
            createApiKeyBtn.disabled = true;
            createApiKeyBtn.textContent = 'Generating...';
            
            const response = await fetch(`${API_BASE}/agent/api-keys`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${localStorage.getItem('token')}`
                },
                body: JSON.stringify({ name })
            });
            
            if (!response.ok) {
                if (response.status === 403) {
                    alert('You do not have permission to manage API keys.');
                } else {
                    alert('Failed to generate API key');
                }
                return;
            }
            
            const result = await response.json();
            
            // Show result
            newApiKeyValue.textContent = result.raw_key;
            newApiKeyResult.style.display = 'block';
            newApiKeyName.value = '';
            
            // Reload list
            loadApiKeys();
            
        } catch (err) {
            console.error('Error generating API key:', err);
            alert('Error generating API key');
        } finally {
            createApiKeyBtn.disabled = false;
            createApiKeyBtn.textContent = 'Generate Key';
        }
    });

    copyApiKeyBtn.addEventListener('click', () => {
        const key = newApiKeyValue.textContent;
        navigator.clipboard.writeText(key).then(() => {
            const originalIcon = copyApiKeyBtn.innerHTML;
            copyApiKeyBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="color: var(--success);"><polyline points="20 6 9 17 4 12"></polyline></svg>';
            setTimeout(() => {
                copyApiKeyBtn.innerHTML = originalIcon;
            }, 2000);
        });
    });
});
